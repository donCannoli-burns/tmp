# KoL-worker Agent Reference & Safe-Build Bundle

## Purpose

This bundle is a **handoff, evidence pack, and reusable build-process reference** built from the supplied KoL-worker hardening artifacts. It is intentionally more than a code drop.

The central idea is:

```text
claim
→ invariant
→ implementation
→ test
→ evidence
```

The original build log explicitly frames the work as a demonstration of process rather than a replacement product: inspect the system, identify trust boundaries, establish authority, make bounded changes, verify behavior, preserve evidence, checkpoint, and independently review before continuing.

Use this bundle to understand **how the hardening work was reasoned about and verified**, then decide which methods, contracts, tests, gates, or implementation ideas belong in the real project.

## Start here

1. Open **`for-agent-project-ref.html`**. It is the supplied `for-solcel-from-don.html.txt` converted into a searchable, internally hyperlinked, line-addressable project reference. The original text is preserved under `source-notes/`.
2. Read **`evidence/IMPLEMENTATION_RESULT.md`** for the compact implementation receipt: provenance, changed surfaces, security properties, test results, and known limitations.
3. Read **`evidence/HARDENED_PROJECT_README.md`** for the implementation's operating model and offline verification commands.
4. Inspect **`reference-implementation/kol-worker-safe/`** when a claim needs to be checked against code or tests.
5. Verify the original source archive with **`artifacts/kol-worker-safe-2bee1e1.tar.gz.sha256`** before using it as a provenance artifact.

## What is in the bundle

```text
kol-worker-agent-reference-bundle/
├── README.md                         # this guide
├── for-agent-project-ref.html        # navigable build/audit/hardening reference
├── source-notes/
│   └── for-solcel-from-don.html.txt  # original supplied reference text
├── evidence/
│   ├── IMPLEMENTATION_RESULT.md      # compact build/test/security receipt
│   └── HARDENED_PROJECT_README.md    # README supplied with the hardened build
├── reference-implementation/
│   └── kol-worker-safe/              # extracted hardened source tree
├── artifacts/
│   ├── kol-worker-safe-2bee1e1.tar.gz                # original hardened source archive
│   └── kol-worker-safe-2bee1e1.tar.gz.sha256         # normalized checksum receipt
└── BUNDLE_MANIFEST.sha256            # checksums for every bundle file except itself
```

## What this bundle is — and is not

It **is**:

- a project-specific example of a safer AI-assisted build process;
- a provenance/evidence pack that connects analysis, implementation, tests, and limitations;
- a reference implementation for studying trust-boundary separation;
- a scaffold that can be copied and adapted for future security-sensitive builds;
- a handoff format that gives another human or agent enough context to audit before modifying.

It is **not**:

- an instruction to replace SolariteCelestial's upstream architecture wholesale;
- proof that the implementation is production-safe merely because the tests pass;
- permission to skip upstream review, licensing review, deployment review, or live-test gates;
- a guarantee of exactly-once mutation or global Cloudflare-isolate serialization;
- a substitute for checking current upstream code and current platform behavior.

## Current evidence boundary

The bundled implementation receipt reports commit `2bee1e19c3ee5ceac91ca83b589bc86fb629d4f3` on `hardening/offline-safe`, with **66/66 adversarial/security checks passing** and no live KoL mutations performed. It also records important unfinished gates: the sandbox could not complete a real Wrangler/workerd dry-run or npm dependency audit, mutation serialization remains isolate-local rather than globally serialized, and generic authenticated WebSocket parity was deliberately withheld.

That means the correct status is the one in the build receipt:

```text
SAFE_FOR_OFFLINE_USE
```

Do not silently upgrade that claim to "production-ready."

## How an agent should use this bundle

A good agent workflow is:

```text
1. establish the user's actual target and authority
2. inspect current upstream / deployment state
3. compare it with this bundle's recorded provenance
4. read the relevant audit finding or invariant in for-agent-project-ref.html
5. inspect the matching source + tests
6. decide whether the method still applies
7. make the smallest bounded change
8. run offline tests and adversarial fixtures
9. record exactly what passed, failed, or could not run
10. checkpoint before any live verification
```

The reference implementation is **evidence**, not an unquestionable template. If upstream has changed, recompute the model from the new system rather than forcing the old patch shape onto it.

## Reusing this as a safer/faster future-build scaffold

For a new project, copy the bundle structure but replace the KoL-specific contents. The reusable shape is:

```text
project-safe-build-bundle/
├── README.md
├── for-agent-project-ref.html
├── source-notes/
│   └── original-context-and-build-log.txt
├── evidence/
│   ├── IMPLEMENTATION_RESULT.md
│   ├── UPSTREAM_PROVENANCE.md
│   └── TEST_RECEIPT.md
├── reference-implementation/
│   └── project-source/
├── artifacts/
│   ├── source-checkpoint.tar.gz
│   └── source-checkpoint.tar.gz.sha256
└── BUNDLE_MANIFEST.sha256
```

Then preserve the same development sequence:

```text
inspect
→ model trust boundaries
→ reproduce only required behavior
→ isolate mutation / privileged authority
→ add enforceable gates
→ test offline
→ adversarial-test the claims
→ preserve receipts and provenance
→ checkpoint
→ independently review
→ pass an explicit live/deployment gate
```

### Make claims executable

For each important claim, write down all five links:

```text
CLAIM
"credentials never reach an unapproved origin"

INVARIANT
credential construction happens only after strict destination validation

IMPLEMENTATION
one centralized authenticated-request primitive

TEST
capture all outbound requests; hostile origin receives no Cookie / pwd / secret

EVIDENCE
saved test output + source commit + artifact hash
```

This makes later audits faster because an agent can walk directly from a statement to the code and test that earn it.

### Separate authority surfaces

A reusable pattern from this build is to avoid treating "the application" as one authority domain. Split surfaces such as:

```text
public / unauthenticated reads
authenticated reads
mutations
administration / secret-bearing operations
external third-party requests
persistent storage
```

Give each surface a different allowlist, request primitive, credential policy, mutation budget, and test battery. Do not rely on prose prompts to keep those boundaries intact.

### Preserve uncertainty

Another reusable rule is:

```text
transport success ≠ semantic success
```

Timeouts, redirects, parser failures, stale state, partial writes, and lost responses should become explicit states such as `UNKNOWN`, `OUTCOME_UNKNOWN`, `RECONCILE_REQUIRED`, or `STOP`, not be translated into success because the code received *some* response.

### Build for recovery, not only the happy path

Before live mutation, define:

- operation identity;
- pre-state and expected post-state where practical;
- hard ceilings / budgets;
- retry rules for idempotent vs. non-idempotent work;
- what survives a client disconnect or process crash;
- what evidence lets the next operator reconcile reality;
- the exact stop condition when the system cannot prove what happened.

### Keep a deployment/live gate separate

Offline tests should be able to establish most security invariants without spending real user authority. A later live gate can then be deliberately small and require prerequisites such as:

```text
build/test pass
runtime/tooling dry-run pass
secrets configured outside source
artifact hash recorded
current source == reviewed source
bounded live action selected
human approval
post-action readback / reconciliation
```

This is both safer and faster than repeatedly debugging against live state.

## Fast fork procedure for a future project

When reusing this bundle, an agent can do the following without inventing a new process from scratch:

1. Rename the bundle and replace the reference implementation with a fresh source snapshot.
2. Record upstream URL, branch, commit, file hashes, inspection date, and license status.
3. Rewrite the trust-boundary section around the new project's real credentials, mutations, external calls, persistence, and admin surfaces.
4. Convert every high-risk claim into an invariant + negative/adversarial test.
5. Put hard limits in code, not only in UI defaults or prompts.
6. Add a compact `IMPLEMENTATION_RESULT.md` that lists what changed, what stayed untouched, exact tests, exact failures, and live actions performed (preferably `NONE` until the gate).
7. Generate a fresh hyperlinked project reference and bundle manifest.
8. Hand the bundle to the next agent/reviewer as the **starting evidence set**, not as a mandate to copy the implementation blindly.

## Integrity

Canonical hardened source archive SHA-256:

```text
e026b5ff8f38635a8e9d0fe24f489d42eef445671b17e2cbde56a1c507631a0d
```

Verify from this directory with:

```bash
cd artifacts
sha256sum -c kol-worker-safe-2bee1e1.tar.gz.sha256
```

`BUNDLE_MANIFEST.sha256` covers the rest of the assembled bundle so that a future reviewer can detect accidental drift in the handoff itself.

## Ownership and adoption

The safest way to use this work is to preserve the upstream maintainer's design authority. Extract the reusable engineering practices, tests, gates, and contracts; adopt implementation details only after checking them against the current project and its goals.
