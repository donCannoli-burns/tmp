# KoL Worker — Safe Reimplementation

This repository contains a security-focused reimplementation of the useful behavior observed in `SolariteCelestial/KoL-worker`.

It is deliberately **not** a line-for-line copy of upstream. The inspected upstream repository has no visible license file, so this implementation treats upstream as a behavioral/reference source and reimplements the required behavior behind stricter trust boundaries.

## Safety posture

The Worker separates four authority surfaces:

- public/reference traffic (KoL Wiki);
- read-only authenticated KoL proxy traffic;
- typed mutating KoL operations;
- administrative KV seeding.

There is no generic authenticated fetch endpoint. A KoL cookie or `pwd` token is attached only after a destination has passed the KoL host policy, and authenticated redirects are processed manually with a bounded redirect budget.

Worker mutation endpoints are POST-only and require same-origin proof plus a CSRF token. Timeouts, upstream 5xx responses, and response-body loss after mutations are reported as `OUTCOME_UNKNOWN`; they are never retried automatically or counted as completed turns.

## Implemented surfaces

- Read-only KoL reverse proxy with explicit path allowlist
- Separate authenticated-read allowlist enforced across redirect hops (read redirects cannot land on adventure.php)
- Host/path URL rewriting for HTML and textual assets
- CSP/X-Frame-Options preservation (no blanket deletion)
- Namespaced, host-scoped upstream cookie translation
- Typed auto-adventure batches with server ceilings
- Mutation redirects restricted to explicit readback/result paths (never back into `adventure.php`)
- Isolate-local operation-ID replay suppression plus same-session in-flight locking
- Fight macros with bounded rounds and conservative state classification
- Choice parsing, exact-fingerprint remembered choices, manual unknown-choice resolution
- Status/spleen endpoint with personalized `no-store` responses
- Direct KoL Wiki location search; external wiki proxy disabled by default
- Personalized account snapshots computed transiently from fixed read-only KoL pages plus KV reference tables
- Snapshot reference pages backed by Cloudflare KV
- Protected KV seeding through `Authorization: Bearer ...` plus same-origin request checks
- Centralized policy and log redaction
- Mobile-capable auto-adventure UI using safe DOM construction
- Restrictive CSP/security headers on Worker-generated privileged pages; executable inline scripts are forbidden


## Build target note

The security-sensitive deliverable is the Cloudflare Worker under `src/worker/`. The pre-existing React/Vite report scaffold (`src/App.tsx`, `index.html`) is retained for provenance but is **not** an authoritative test surface and is not the default build target. `npm run build` and `npm run typecheck` now compile the Worker; the old report UI is available only through `report:*` scripts.

## Offline verification

No real KoL actions are required for the test suite.

```bash
npm run check:security
```

That runs:

```text
TypeScript Worker compile
        ↓
mocked/adversarial security suite
        ↓
outbound request capture assertions
```

The security suite currently runs 66 checks. It proves, among other cases, that an attacker-host redirect causes **no authenticated second request**, cross-origin mutation is rejected, unknown choices stop, changed choice fingerprints stop, fight ceilings stop, personalized snapshot HTML is not persisted, CSP/X-Frame-Options are preserved, and mutation network failures are not retried.

## Cloudflare tooling

Cloudflare currently recommends project-local Wrangler and `wrangler.jsonc`. The pinned dry-run command is:

```bash
npm run worker:dry-run
```

which resolves Wrangler `4.142.0` explicitly. This environment could not complete the Wrangler download within the available execution window, so a real `workerd`/Wrangler dry-run remains a required checkpoint before any live KoL mutation.

`wrangler.jsonc` intentionally does not contain a KV namespace ID or admin secret. Add your own KV namespace binding named `SNAPSHOT_KV`, then add the administrator secret with Cloudflare secret storage, for example:

```bash
npx --yes wrangler@4.142.0 secret put KV_SEED_KEY
```

Do not put `KV_SEED_KEY` in `vars`, source control, URLs, or browser storage.

## Configuration

Security-sensitive defaults live in `src/worker/policy.ts`.

Important ceilings include:

- 10 turns per requested batch by default
- 100 absolute turn ceiling
- 30 fight rounds
- 10 choice-chain steps
- 5 authenticated redirects
- 96 upstream requests per operation
- 15-second upstream timeout
- 120-second total automation timeout

Client values can only reduce or request within server-side authority; they cannot disable a ceiling.

## Cookie model

Browser-visible proxy cookies are namespaced as `kol_upstream_<name>`. Only that namespace is reconstructed into the KoL `Cookie` header. Worker cookies, including the CSRF cookie, are excluded structurally.

Translated KoL cookies are emitted with:

```text
Path=/; Secure; HttpOnly; SameSite=Lax
```

and without an upstream `Domain` attribute. See `docs/SECURITY_ARCHITECTURE.md` for the exact consequences.

## Live testing gate

This repository performed **no live KoL mutations** during this build. Before a first bounded live test, complete `docs/LIVE_TEST_GATE.md`, including a Wrangler/workerd runtime pass.

## Documentation

- `docs/UPSTREAM_PROVENANCE.md` — inspected upstream revision and file fingerprints
- `docs/SECURITY_ARCHITECTURE.md` — authority separation and credential flow
- `docs/THREAT_MODEL.md` — threats, invariants, and limitations
- `docs/LIVE_TEST_GATE.md` — mandatory pre-live checkpoint

## License / attribution note

The upstream repository was inspected for behavior and provenance. No `LICENSE` file was present at the inspected revision. This repository therefore does not assert a right to redistribute upstream source or upstream snapshot datasets. The implementation in `src/worker/` was written as a safety-oriented behavioral reimplementation; the upstream snapshot data files were inventoried but not copied into this project.

## Deliberately withheld parity

The inspected upstream worker contains a generic WebSocket pass-through. This implementation does **not** enable a generic authenticated WebSocket tunnel because the exact KoL WebSocket endpoint and its mutation/social authority were not proven during the offline build. Adding a WebSocket path requires an explicit typed/allowlisted policy and runtime tests; it must not be restored as a generic authenticated proxy.
