# Live KoL mutation gate

No live KoL mutations were performed during this build.

Do not run the first live mutation until every item below is recorded for the exact commit being tested.

## Required checkpoint

```text
commit SHA:
working tree clean: YES / NO
Wrangler version: 4.142.0
workerd/Wrangler dry-run: PASS / FAIL
security suite: PASS / FAIL
security test count:
dependency audit result:
known limitations:
```

## Exact first action

```text
target location:
snarfblat:
requested turns: 1
maximum possible game cost: 1 adventure
macro: none unless explicitly required
expected upstream mutation request count:
expected choice behavior: stop on unknown
expected fight behavior: bounded / stop on uncertainty
```

## Stop conditions

Stop without retry if any of the following occurs:

- session state is ambiguous;
- cookie destination cannot be proven;
- any redirect leaves the KoL allowlist;
- `pwd` extraction is unreliable;
- an unknown or changed choice appears;
- fight state is uncertain;
- fixture behavior materially disagrees with live KoL;
- any security test fails;
- the working tree contains unexplained changes;
- a request times out after it may have mutated state;
- the live request outcome is unknown.

## Recovery

On an ambiguous live mutation:

```text
DO NOT resend the mutation
→ refresh read-only account/game state
→ determine whether the action already occurred
→ record the evidence
→ only then decide whether a new mutation is safe
```

The UI Stop control prevents issuance of the **next** action. It cannot cancel or undo an HTTP request already accepted upstream.
