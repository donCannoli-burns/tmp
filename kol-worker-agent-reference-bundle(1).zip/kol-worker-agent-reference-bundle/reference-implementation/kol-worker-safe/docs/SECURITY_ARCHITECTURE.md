# Security architecture

## Trust boundaries

```text
browser
  ├── GET public/reference ───────> Worker ───────> KoL Wiki
  ├── GET/HEAD read-only proxy ───> Worker ───────> KoL read allowlist
  ├── POST typed mutation ────────> Worker ───────> KoL typed operations
  └── POST admin seed ────────────> Worker ───────> Cloudflare KV
```

These are separate code paths. There is no generic authenticated URL fetch endpoint.

## Authority map

| Surface | Browser method | Credentials | Destination policy | Mutation authority |
|---|---|---|---|---|
| `/kol-locations/search` | GET | none forwarded | configured trusted Wiki HTTPS origin | none |
| read-only proxy | GET/HEAD | namespaced KoL cookies only | exact KoL host + explicit read-path allowlist | none by Worker contract |
| `/api/status` | GET | KoL cookie | fixed KoL status URL | none |
| `/api/auto-adventure/run` | POST | KoL cookie + fetched KoL `pwd` | fixed typed KoL adventure/fight/choice paths | bounded |
| `/api/choice/resolve` | POST | KoL cookie + fetched KoL `pwd` | fixed typed KoL choice path | one validated choice submission |
| `/api/kv-seed/:category` | POST | admin bearer secret, never KoL auth | Cloudflare KV binding | one validated category replacement |
| login proxy | POST | namespaced KoL cookies | fixed canonical `/login.php` | login only |

## Authenticated KoL primitive

`safeKoLRequest()` performs the following order:

```text
parse URL
→ require HTTPS
→ reject userinfo/IP/localhost/host confusion
→ require exact approved KoL host
→ construct authenticated headers
→ send with redirect=manual
→ inspect Location
→ validate next KoL hop
→ enforce redirect ceiling
→ follow only allowed semantics
```

Credentials are not constructed before URL validation succeeds.

A mutating `307`/`308` is never replayed. A network failure or ambiguous mutating request returns `OUTCOME_UNKNOWN` rather than retrying.

## Browser-cookie translation

Raw KoL cookies are never stored under their original browser cookie names on the Worker host. Upstream cookies are translated to:

```text
kol_upstream_<original-name>=<value>
```

Only names with that prefix are reconstructed for KoL. This prevents the Worker's CSRF cookie and unrelated Worker cookies from being forwarded upstream.

Re-emitted upstream cookies are host-scoped and forced to:

```text
Path=/; Secure; HttpOnly; SameSite=Lax
```

The upstream `Domain`, `Path`, `Secure`, `HttpOnly`, and `SameSite` attributes are not blindly copied. `Expires` and `Max-Age` are preserved when present.

Security consequence: this intentionally narrows cookie scope to the Worker host. It may differ from exact upstream cross-subdomain semantics; this is a compatibility tradeoff chosen to prevent credential scope expansion.

## CSRF model

Typed mutations require all of:

- `POST`;
- exact Worker `Origin`;
- `Sec-Fetch-Site: same-origin` when supplied;
- `X-KoL-Action: mutate`;
- CSRF token header matching a `Secure; HttpOnly; SameSite=Strict` Worker cookie;
- a syntactically valid operation ID.

The CSRF token is issued by same-origin `/api/csrf` and returned in JSON for the privileged same-origin UI. Cross-origin pages cannot read that response under the browser same-origin policy and their mutation request is independently rejected on `Origin`.

## Mutation budgets

The central policy object enforces hard ceilings for turns, fight rounds, choice depth, redirects, upstream requests, request body sizes, per-request timeout, and total operation timeout.

The client cannot increase these limits. User turn requests are calculated as:

```text
min(requested, configured batch limit, absolute server limit)
```

## Choice safety

Remembered answers use:

```text
whichchoice::option:label|option:label|...
```

with a sorted option fingerprint. A human choice submission re-fetches the current choice, recomputes the fingerprint, confirms that the requested option still exists, and only then submits it.

Unknown, empty, changed, or unparseable choices stop. No LLM or heuristic is permitted to invent an answer.

## Fight safety

Fight automation is bounded. The classifier distinguishes:

```text
RESOLVED
STILL_IN_FIGHT
SESSION_EXPIRED
UNKNOWN
```

Identical repeated fight bodies are classified as `UNKNOWN`, not victory. Network ambiguity is not retried.

## HTML/script transformation

The proxy keeps upstream `Content-Security-Policy` and `X-Frame-Options` instead of deleting them wholesale. The auto-adventure helper is injected only when the existing CSP permits a same-origin script.

The privileged UI code uses DOM creation and `textContent`; it does not use `eval`, `new Function`, `innerHTML`, or remote arbitrary scripts.

## KV administration

The administrator secret is accepted only as a bearer header. Query-string secret parameters are rejected. The admin page does not persist the secret, clears the password input after use, and never prints it.

A category is committed to KV only after the entire upload passes category, byte, row, column, field-length, and text validation. Personalized account pages and KoL credentials are never written to KV.

## Snapshot privacy

Personalized snapshots fetch only fixed KoL pages for the selected category, compare those transient HTML responses to deployer-seeded reference rows, and return a derived list of owned/permed entries. Raw account HTML is not written to KV. Personalized snapshot API responses use `no-store`.

## WebSocket boundary

The upstream worker generically forwards a successful WebSocket upgrade. That mechanism is intentionally withheld here: a generic authenticated WebSocket tunnel would recreate the forbidden generic-authenticated-proxy authority, and the exact modern KoL WebSocket path/semantics were not proven offline. WebSocket support must be introduced only as a separately allowlisted typed boundary after endpoint and runtime verification.

## Concurrency limitation

The implementation has an in-isolate mutation lock keyed by a hash of the KoL session cookie. This prevents overlapping mutations within one Worker isolate.

**It is not a globally atomic cross-isolate lock.** Cloudflare may execute requests in multiple isolates. Before production or a bounded live test that depends on duplicate suppression, this should be validated in `workerd` and, if global serialization is required, replaced or augmented with a Durable Object or another Cloudflare-supported strongly consistent coordination primitive.


## Authenticated-read path invariant

Host validation is not enough for a read authority boundary because KoL has state-changing GET surfaces. Typed internal reads therefore use a separate `allowedAuthenticatedReadPaths` policy. The initial destination and every redirect hop are checked against that list before a credentialed request is issued. A read of `charpane.php` redirected to `adventure.php` is rejected before the second request.

## Worker-generated page CSP

Worker-owned UI pages use same-origin external scripts and a restrictive CSP (`default-src 'none'`, `script-src 'self'`, `connect-src 'self'`, `frame-ancestors 'none'`). Executable inline `<script>` blocks are forbidden by the static security scan. Inline styles remain permitted for the small built-in UI.

## Mutation serialization limitation

The current duplicate-operation guard is isolate-local. It prevents overlapping same-session mutations inside one Worker isolate but is not a distributed lock across Cloudflare isolates. This is sufficient for offline verification only; multi-isolate live deployment should use a Durable Object or equivalent strongly serialized coordinator before claiming global duplicate suppression.


## Mutation redirect path invariant

A state-changing request may receive a 301/302/303, but the Worker does not treat every KoL URL as a safe readback target. Only `allowedMutationRedirectReadPaths` may be followed after the first mutation. In particular, `adventure.php` is excluded so a redirect cannot silently spend an additional turn inside one logical operation. 307/308 mutation redirects are never replayed and are classified as `OUTCOME_UNKNOWN`.

## Ambiguous upstream completion

For state-changing requests, network failure, response-body loss, and upstream 5xx responses are treated conservatively as `OUTCOME_UNKNOWN`. They are not retried and are not counted as completed turns.

## Isolate-local replay suppression

The Worker reserves a `(session hash, operation ID)` before mutation and rejects a repeated operation ID for a bounded TTL. This blocks ordinary browser retry/replay within one isolate. It does not replace the documented need for a strongly serialized cross-isolate coordinator before claiming global duplicate suppression.
