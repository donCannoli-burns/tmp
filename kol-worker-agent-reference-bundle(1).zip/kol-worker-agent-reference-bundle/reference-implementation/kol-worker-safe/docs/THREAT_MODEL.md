# KoL Worker threat model

## Protected assets

- KoL session cookies
- KoL `pwd` tokens
- administrator `KV_SEED_KEY`
- adventure turns and other mutable account state
- personalized account data
- snapshot KV integrity

## Principal threats

1. hostile target URL or redirect attempts to exfiltrate KoL credentials;
2. cross-origin pages trigger account mutations;
3. ambiguous network failures cause duplicate non-idempotent actions;
4. automation exceeds intended turn/fight/choice/request limits;
5. stale remembered choices select a different option after game markup changes;
6. admin secrets leak through URLs, logs, storage, or responses;
7. hostile upstream/user strings become executable HTML/JavaScript;
8. third-party wiki infrastructure receives KoL authentication;
9. personalized responses enter shared caches;
10. debug or generic proxy behavior expands authority.

## Security invariants

| Claim | Enforcement | Executable evidence |
|---|---|---|
| KoL cookie/pwd never goes to non-KoL origin | destination validated before credential construction; every server-side auth redirect revalidated | captured outbound request tests for attacker target + attacker redirect |
| mutation is explicit | Worker mutation routes are POST-only; generic proxy mutation rejected | GET mutation and generic POST proxy tests |
| cross-origin mutation fails | exact Origin + fetch-site + action header + CSRF token | cross-origin/missing-proof tests |
| client cannot disable budgets | central policy + finite integer validation + min ceilings | huge/negative/NaN/Infinity tests |
| ambiguous mutation is not retried | one-attempt transport + `OUTCOME_UNKNOWN` | throwing mocked fetch call count == 1 |
| unknown/changed choice stops | exact option fingerprint + re-read before human submit | unknown-choice and changed-fingerprint tests |
| fight uncertainty stops | bounded rounds + explicit UNKNOWN state | fight ceiling and parser/classifier tests |
| admin secret stays out of URL/log | bearer-only admin route + query secret rejection + redactor | runtime query-secret + redaction tests |
| only known KV categories commit | policy allowlist + full upload validation before `put` | invalid category / oversized upload tests |
| personalized responses are non-cacheable | `Cache-Control: no-store...` + `Pragma: no-cache` | authenticated status response test |
| third-party wiki sees no KoL auth | public-only header constructor | captured external wiki request test |
| hostile strings are rendered as text | HTML escaping + DOM `textContent` | XSS fixture tests |
| CSP/XFO are not blindly removed | safe response-header copy and CSP-aware injection | static implementation + offline compile |

## Stop-over-guess design

The implementation deliberately stops on states it cannot prove. This includes unknown choices, changed choice fingerprints, identical fight responses, login redirects, invalid redirect destinations, request ceilings, and ambiguous mutation failures.

## Known limitations

- The Worker has not yet executed under real `workerd`/Wrangler in this sandbox because the pinned Wrangler package download timed out.
- The in-isolate mutation lock is not a globally atomic Cloudflare lock across isolates.
- Generic upstream WebSocket pass-through is intentionally disabled until a specific KoL WebSocket path and its authority can be proven and allowlisted.
- Browser/proxy compatibility with every KoL page is intentionally subordinate to the explicit read-path allowlist; additional paths should be admitted only after their mutation semantics are understood.
- Upstream has no visible license file at the inspected revision, so upstream source/data redistribution rights are not assumed.


### Read-to-mutation redirect drift

A credentialed read is not allowed to follow a redirect onto a state-changing KoL GET path. The authenticated-read path allowlist is checked before the first request and again before every redirected request.

### Cross-isolate duplicate mutation

The current in-memory session lock is an isolate-local defense, not a distributed transaction primitive. A multi-isolate production deployment therefore has a known duplicate-mutation race unless a strongly serialized coordinator (for example a Durable Object) is added. Until then, this implementation is offline-safe but does not claim globally serialized production mutation execution.


### Mutation redirect replay

A 301/302/303 emitted after a state-changing action is followed only when its destination is an explicit non-turn-spending readback/result path. Redirects back to `adventure.php` are rejected before a second request. 307/308 are never replayed.

### Ambiguous HTTP completion

A mutation that receives a 5xx response, loses its response body, or fails at the network boundary is treated as `OUTCOME_UNKNOWN`. The turn counter is not advanced and the Worker does not retry automatically.
