# Upstream provenance — SolariteCelestial/KoL-worker

Inspection date: **2026-09-28**

Repository: `https://github.com/SolariteCelestial/KoL-worker`

Default branch: `main`

Inspected HEAD:

```text
84a28ebb02a4d493a28ce26966e64d402a59a65c
```

The build prompt referenced an earlier observed HEAD:

```text
bbce317d78a1cbfbec980a4efabbd803684e3021
```

GitHub comparison reported the inspected HEAD as 17 commits ahead of that prompt snapshot. Changes included small edits to `README.md` and `current_worker` plus snapshot reference-data files.

## License disposition

No `LICENSE` file was present at the inspected revision. Because copying rights are therefore unclear, this project does not silently duplicate substantial upstream source. The Worker implementation is a behavioral reimplementation. Upstream snapshot datasets are inventoried here but are not copied into the implementation tree.

## Inspected file inventory

The following Git blob SHAs were returned for the exact inspected HEAD.

| Path | Git blob SHA | Size (bytes) | Lines |
|---|---|---:|---:|
| `README.md` | `49f985a53b89520393459290f390a56c3fb297bd` | 846 | 13 |
| `current_worker` | `6b6e088f4f5883c9ac2a7d0853cc105c846a0592` | 76,437 | 1,751 |
| `snapshot/av-snapshot-booze.txt` | `5ba0aee53c807ccd58bdb104e95870ba2e4efaac` | 18,100 | 802 |
| `snapshot/av-snapshot-coolitems.txt` | `8b6ec7f148670f4bca2d278274798bf46a90130b` | 36,606 | 810 |
| `snapshot/av-snapshot-disc-cocktail.txt` | `7d5e8e9e33e5f8714c5564891069687e61fb882e` | 11,219 | 278 |
| `snapshot/av-snapshot-disc-food.txt` | `ac01cb76e277f9aa4908528f0cac7c99f5bc51bf` | 15,732 | 414 |
| `snapshot/av-snapshot-disc-meat.txt` | `aaee94157ab03280ece3621c909d637297f5e99e` | 13,245 | 330 |
| `snapshot/av-snapshot-disc-misc.txt` | `889f808ad02f0ed5204225e14a012b7a44b4f383` | 5,805 | 163 |
| `snapshot/av-snapshot-disc-smith.txt` | `b24d297aef3115b2a38347e53afb627e14b2d218` | 12,010 | 320 |
| `snapshot/av-snapshot-food.txt` | `c1e058f4c704d3f55266d41f59b952ec013e3611` | 23,522 | 1,042 |
| `snapshot/av-snapshot-info.txt` | `004bde9c4c07962397864bffd4fed17f082af6d4` | 29 | 3 |
| `snapshot/av-snapshot-skills.txt` | `c5b61cbb62faac92a43b004f7a586eb3569266d0` | 26,672 | 458 |
| `snapshot/av-snapshot-tattoos.txt` | `01e25a79d2f19f217538e1dcd37f5f70eaa1edca` | 26,531 | 327 |
| `snapshot/av-snapshot-trophies.txt` | `f4b9baa2def06b0b4278f63d25bea4e6bd31838a` | 14,340 | 165 |
| `snapshot/familiars-corrected.txt` | `db25e4146f52e0acb8c7579c80585513e4b964eb` | 9,109 | 324 |

## Behavioral reference observations

The inspected `current_worker` was used to map behavior, not as a security specification. In particular, the reference contains mechanisms that this implementation intentionally replaces:

- browser auto-adventure calls a GET mutation route;
- adventure/fight/choice authenticated requests use automatic redirect following;
- KV seeding sends the administrator key in a URL query string;
- a monolithic proxy and mutation surface makes authority boundaries harder to prove.

The safe implementation preserves useful user-visible capabilities while replacing those mechanisms with typed POST APIs, explicit host/path policy, manual redirects, CSRF proof, bounded mutation budgets, and centralized credential handling.
