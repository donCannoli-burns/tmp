import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
const lock=JSON.parse(fs.readFileSync(new URL('../package-lock.json',import.meta.url),'utf8'));
let failed=false;
for(const section of ['dependencies','devDependencies']){
  for(const [name,declared] of Object.entries(pkg[section]||{})){
    if(/^[~^*]|\s|[<>|]/.test(String(declared))){console.error(`UNPINNED ${section} ${name}=${declared}`);failed=true;continue}
    const locked=lock.packages?.[`node_modules/${name}`]?.version;
    const root=lock.packages?.['']?.[section]?.[name];
    if(locked!==declared||root!==declared){console.error(`LOCK_MISMATCH ${name}: package=${declared} rootLock=${root} resolved=${locked}`);failed=true}
  }
}
if(failed)process.exit(1);
console.log('package pins: PASS');
