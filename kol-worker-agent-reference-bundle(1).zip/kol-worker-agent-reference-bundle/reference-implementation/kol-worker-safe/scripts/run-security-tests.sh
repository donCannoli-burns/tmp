#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf .test-build
tsc -p tsconfig.tests.json
printf '%s\n' '{"type":"commonjs"}' > .test-build/package.json
node .test-build/tests/security-tests.js
