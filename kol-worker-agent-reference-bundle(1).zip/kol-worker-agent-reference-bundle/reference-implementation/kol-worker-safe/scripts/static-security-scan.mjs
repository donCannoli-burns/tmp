import fs from 'node:fs';import path from 'node:path';
const root=new URL('../src/worker/',import.meta.url);const dir=decodeURIComponent(root.pathname);
const files=fs.readdirSync(dir).filter(x=>x.endsWith('.ts'));
const forbidden=[
  ['blind redirect follow',/redirect\s*:\s*['"]follow['"]/],
  ['eval',/\beval\s*\(/],
  ['new Function',/new\s+Function\b/],
  ['innerHTML',/\.innerHTML\b/],
  ['admin secret query construction',/\?key=|searchParams\.set\(['"](?:key|secret|password|kv_seed_key)['"]/i],
  ['inline executable script tag',/<script(?![^>]*\bsrc=)[^>]*>/i],
];
let failed=false;
for(const file of files){const text=fs.readFileSync(path.join(dir,file),'utf8');for(const [label,re] of forbidden){if(re.test(text)){console.error(`FORBIDDEN ${label}: src/worker/${file}`);failed=true}}}
if(failed)process.exit(1);
console.log('static security scan: PASS');
