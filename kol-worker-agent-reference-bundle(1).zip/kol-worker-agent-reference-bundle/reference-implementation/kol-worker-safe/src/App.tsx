import { useState, useEffect } from 'react';
import { runAllTests, TestResult } from './tests/security-tests';

type Tab = 'overview' | 'architecture' | 'tests' | 'trust' | 'policy' | 'report';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [testResults, setTestResults] = useState<{ results: TestResult[]; passed: number; failed: number; total: number } | null>(null);
  const [testsRun, setTestsRun] = useState(false);

  useEffect(() => {
    const results = runAllTests();
    setTestResults(results);
    setTestsRun(true);
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <span className="text-emerald-400 font-bold text-sm">KW</span>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-100">KoL-Worker Safe Implementation</h1>
              <p className="text-xs text-gray-500">Hardened Cloudflare Worker for Kingdom of Loathing</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {testsRun && testResults && (
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                testResults.failed === 0 
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}>
                {testResults.passed}/{testResults.total} tests passed
              </div>
            )}
            <span className="px-2 py-1 rounded bg-gray-800 text-xs text-gray-400 border border-gray-700">
              SAFE_FOR_OFFLINE_USE
            </span>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b border-gray-800 bg-gray-900/30">
        <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {(['overview', 'architecture', 'trust', 'policy', 'tests', 'report'] as Tab[]).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab
                  ? 'border-emerald-500 text-emerald-400'
                  : 'border-transparent text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'overview' && <OverviewTab testResults={testResults} />}
        {activeTab === 'architecture' && <ArchitectureTab />}
        {activeTab === 'trust' && <TrustTab />}
        {activeTab === 'policy' && <PolicyTab />}
        {activeTab === 'tests' && <TestsTab testResults={testResults} />}
        {activeTab === 'report' && <ReportTab testResults={testResults} />}
      </main>
    </div>
  );
}

// ─── Overview Tab ────────────────────────────────────────────────────────────

function OverviewTab({ testResults }: { testResults: { passed: number; failed: number; total: number } | null }) {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Implementation Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard label="Security Invariants" value="12" subtitle="enforced structurally" color="emerald" />
          <StatCard label="Trust Boundaries" value="7" subtitle="explicitly modeled" color="blue" />
          <StatCard label="Test Cases" value={testResults?.total.toString() || '...'} subtitle={`${testResults?.passed || 0} passing`} color="purple" />
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Upstream Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-medium text-gray-400 mb-2">Source Provenance</h4>
            <dl className="space-y-1 text-sm">
              <div className="flex gap-2"><dt className="text-gray-500">Repository:</dt><dd className="text-gray-300">SolariteCelestial/KoL-worker</dd></div>
              <div className="flex gap-2"><dt className="text-gray-500">Branch:</dt><dd className="text-gray-300">main</dd></div>
              <div className="flex gap-2"><dt className="text-gray-500">HEAD:</dt><dd className="text-gray-300 font-mono text-xs">bbce317d78a1cbfbec980a4efabbd803684e3021</dd></div>
              <div className="flex gap-2"><dt className="text-gray-500">Date Inspected:</dt><dd className="text-gray-300">2026-09-26</dd></div>
              <div className="flex gap-2"><dt className="text-gray-500">License:</dt><dd className="text-yellow-400">None specified — behavior reimplemented, not copied</dd></div>
            </dl>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-400 mb-2">Files Used as Reference</h4>
            <ul className="space-y-1 text-sm text-gray-300">
              <li className="font-mono text-xs">current_worker (single-file worker)</li>
              <li className="font-mono text-xs">README.md</li>
            </ul>
            <p className="text-xs text-gray-500 mt-3">
              No substantial code was copied. Behavior was understood from the reference and reimplemented with safety improvements.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Critical Security Changes</h3>
        <div className="space-y-3">
          <SecurityChange
            severity="critical"
            title="Target URL Validation Hardened"
            description="The reference implementation's extractKolTarget() permits arbitrary URLs to fall through. This implementation REQUIRES explicit validation — scheme, hostname, path, and snarfblat must all match."
          />
          <SecurityChange
            severity="critical"
            title="Mutations Require POST"
            description="The reference uses GET for /auto-adventure/run which can spend adventures. This implementation requires POST with CSRF protection for all state-changing operations."
          />
          <SecurityChange
            severity="critical"
            title="Admin Secret Moved to Authorization Header"
            description="The reference sends KV_SEED_KEY in URL query strings (?key=SECRET). This implementation requires Bearer token in Authorization header, preventing leakage via logs, history, and referrers."
          />
          <SecurityChange
            severity="high"
            title="Manual Redirect Validation"
            description="The reference uses redirect:'follow' with auth headers. This implementation validates every redirect hop against the KoL host allowlist before forwarding credentials."
          />
          <SecurityChange
            severity="high"
            title="No Automatic Retry of Mutations"
            description="Timeouts now return OUTCOME_UNKNOWN instead of silently retrying. A lost response does not mean the action didn't occur."
          />
          <SecurityChange
            severity="high"
            title="Debug Endpoint Gated"
            description="The ?raw=1 debug endpoint that exposes raw authenticated content is disabled by default and requires explicit debug authorization."
          />
          <SecurityChange
            severity="medium"
            title="CSP Headers Analyzed Before Removal"
            description="Rather than blindly stripping Content-Security-Policy, each header modification is documented with justification."
          />
          <SecurityChange
            severity="medium"
            title="Wiki Proxy Disabled by Default"
            description="The hard-coded third-party wiki proxy is disabled. If enabled, it must be explicitly configured and KoL credentials are never sent to it."
          />
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Functional Behavior Preserved</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          {[
            'KoL reverse proxy with URL rewriting',
            'HTML attribute rewriting (href, src, action, srcset)',
            'fetch/XHR/WebSocket compatibility injection',
            'Responsive auto-adventure UI panel',
            'Standalone auto-adventure page',
            'Bounded adventure execution with turn limits',
            'Fight handling with macro support',
            'Choice adventure detection and manual selection',
            'Remembered choices with fingerprint-keyed storage',
            'Spleen status display',
            'KoL location search via wiki',
            'Snapshot pages with KV-backed reference data',
            'KV seeding admin workflow',
            'Session-expiration detection',
            'Mobile-responsive design',
          ].map(item => (
            <div key={item} className="flex items-center gap-2">
              <span className="text-emerald-400">✓</span>
              <span className="text-gray-300">{item}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

// ─── Architecture Tab ────────────────────────────────────────────────────────

function ArchitectureTab() {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Module Architecture</h2>
        <p className="text-gray-400 mb-6">
          The monolithic worker is separated into understandable modules with explicit trust boundaries.
          Separation of authority may not be violated.
        </p>
        
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 font-mono text-sm">
          <pre className="text-gray-300 overflow-x-auto">{`src/worker/
├── policy.ts          # Central policy configuration, turn budgets
├── host-policy.ts     # URL validation, host allowlist, redirect safety
├── safe-request.ts    # Authenticated KoL request primitive
├── csrf.ts            # CSRF/same-origin defense, CORS headers
├── redact.ts          # Log redaction for sensitive data
├── adventure.ts       # Adventure, fight, choice logic
├── kv-seed.ts         # Admin authentication, KV input validation
└── index.ts           # Worker entry point, routing

src/tests/
└── security-tests.ts  # Comprehensive security test battery`}</pre>
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Module Responsibilities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ModuleCard
            name="policy.ts"
            description="Central configuration for all security limits. Client values can NEVER exceed server ceilings."
            exports={['PolicyConfig', 'DEFAULT_POLICY', 'validatePolicy', 'computeTurnBudget']}
            color="emerald"
          />
          <ModuleCard
            name="host-policy.ts"
            description="URL validation and credential isolation. The GATE for all authenticated requests."
            exports={['validateKolUrl', 'validateAdventureTarget', 'validateRedirectLocation', 'isAllowedKolHost']}
            color="blue"
          />
          <ModuleCard
            name="safe-request.ts"
            description="The single authenticated KoL request primitive. Credentials attached ONLY after hostname validation."
            exports={['safeKoLRequest', 'classifyRequestType', 'assertMutatingMethod']}
            color="purple"
          />
          <ModuleCard
            name="csrf.ts"
            description="CSRF and same-origin defense. POST-only mutation, Origin validation, custom action header."
            exports={['validateCsrf', 'restrictiveCorsHeaders', 'noStoreHeaders']}
            color="orange"
          />
          <ModuleCard
            name="redact.ts"
            description="Centralized log redaction. Prevents credential leakage in logs."
            exports={['redactForLog', 'redactHeaders', 'redactUrl', 'formatLogEntry']}
            color="yellow"
          />
          <ModuleCard
            name="adventure.ts"
            description="Adventure execution, fight resolution, choice parsing. Hardened target validation."
            exports={['extractAndValidateTarget', 'parseChoiceForms', 'classifyFightState', 'choiceKey']}
            color="pink"
          />
          <ModuleCard
            name="kv-seed.ts"
            description="Admin authentication via Authorization header. Explicit category allowlist. Input validation."
            exports={['validateAdminAuth', 'validateCategory', 'validateSeedInput', 'validateSeedRequest']}
            color="cyan"
          />
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Request Flow</h3>
        <div className="font-mono text-xs text-gray-400 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">1.</span>
            <span>Browser → Worker: Request arrives</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">2.</span>
            <span>Route classified: public | read-only | mutating | admin</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">3.</span>
            <span>If mutating: CSRF validated (POST + Origin + X-KoL-Action)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">4.</span>
            <span>Target URL validated against KoL host allowlist</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">5.</span>
            <span>Credentials attached ONLY after validation passes</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">6.</span>
            <span>Request sent with manual redirect handling</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">7.</span>
            <span>Each redirect hop validated before following</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400">8.</span>
            <span>Response returned with appropriate cache headers</span>
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── Trust Boundaries Tab ────────────────────────────────────────────────────

function TrustTab() {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Trust Boundaries</h2>
        <p className="text-gray-400 mb-6">
          Each zone is modeled explicitly. A caller cannot accidentally cross boundaries.
        </p>
        
        <div className="space-y-4">
          <TrustBoundary
            id="browser-ui"
            name="Browser → Worker UI"
            description="Injected scripts execute in authenticated KoL proxy context. Treated as privileged code."
            rules={['No eval or new Function', 'No remote arbitrary scripts', 'textContent where possible', 'Explicit escaping for HTML construction']}
            color="blue"
          />
          <TrustBoundary
            id="read-only"
            name="Browser → Read-only Worker → KoL"
            description="Read-only endpoints forward requests without mutation. No state changes."
            rules={['GET only', 'No pwd attachment unless needed', 'Response caching controlled', 'No cookie broadening']}
            color="emerald"
          />
          <TrustBoundary
            id="mutating"
            name="Browser → Mutating Worker → KoL"
            description="State-changing operations. POST-only with CSRF protection."
            rules={['POST only', 'CSRF validated', 'Turn budget enforced', 'No automatic retry on timeout']}
            color="orange"
          />
          <TrustBoundary
            id="admin"
            name="Browser → KV Administration"
            description="Administrative operations. Protected by Authorization header."
            rules={['Bearer token required', 'Category allowlist enforced', 'Input size validated', 'Secret never in URL']}
            color="red"
          />
          <TrustBoundary
            id="worker-kol"
            name="Worker → Kingdom of Loathing"
            description="Authenticated upstream requests. Credentials isolated to KoL hosts only."
            rules={['Host allowlist enforced', 'HTTPS required', 'Manual redirect validation', 'Credential isolation guaranteed']}
            color="purple"
          />
          <TrustBoundary
            id="worker-wiki"
            name="Worker → KoL Wiki"
            description="Public wiki access. No KoL credentials sent."
            rules={['No authentication forwarded', 'Configurable origin', 'Default disabled', 'Rate-limited']}
            color="cyan"
          />
          <TrustBoundary
            id="worker-kv"
            name="Worker → Cloudflare KV"
            description="Reference data storage. No personalized data persisted."
            rules={['Category allowlist', 'Size limits enforced', 'No session cookies stored', 'No personalized HTML stored']}
            color="yellow"
          />
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Credential Flow Invariant</h3>
        <div className="bg-gray-950 border border-gray-700 rounded-lg p-4 font-mono text-sm">
          <p className="text-emerald-400 mb-2">ABSOLUTE INVARIANT:</p>
          <p className="text-gray-300">
            A KoL session cookie or pwd token MUST NEVER be transmitted to a non-KoL origin.
          </p>
          <p className="text-gray-500 mt-3">Enforced structurally by:</p>
          <ul className="text-gray-400 mt-1 space-y-1">
            <li>• validateKolUrl() checks hostname BEFORE credentials are attached</li>
            <li>• safeKoLRequest() validates destination first, then builds headers</li>
            <li>• validateRedirectLocation() checks every redirect hop</li>
            <li>• buildSafeHeaders() only called after URL passes validation</li>
          </ul>
        </div>
      </section>
    </div>
  );
}

// ─── Policy Tab ──────────────────────────────────────────────────────────────

function PolicyTab() {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Central Policy Configuration</h2>
        <p className="text-gray-400 mb-6">
          All security-relevant limits are defined in one place. Configuration is validated at startup and fails closed on invalid values.
        </p>
        
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800 bg-gray-900/50">
                <th className="text-left px-4 py-3 text-gray-400 font-medium">Parameter</th>
                <th className="text-left px-4 py-3 text-gray-400 font-medium">Value</th>
                <th className="text-left px-4 py-3 text-gray-400 font-medium">Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              <PolicyRow name="allowedKolHosts" value="www.kingdomofloathing.com, kingdomofloathing.com" reason="Exact host allowlist" />
              <PolicyRow name="maxTurnsPerBatch" value="10" reason="Prevents accidental large batches" />
              <PolicyRow name="absoluteMaxTurns" value="100" reason="Hard server ceiling" />
              <PolicyRow name="maxFightRounds" value="30" reason="Prevents infinite fight loops" />
              <PolicyRow name="maxChoiceDepth" value="10" reason="Prevents choice chain loops" />
              <PolicyRow name="maxRedirects" value="5" reason="Prevents redirect loops/attacks" />
              <PolicyRow name="upstreamTimeoutMs" value="15000" reason="15s per upstream request" />
              <PolicyRow name="totalOperationTimeoutMs" value="120000" reason="2min total operation limit" />
              <PolicyRow name="maxSeedBytes" value="10MB" reason="Prevents KV abuse" />
              <PolicyRow name="maxSeedRows" value="50000" reason="Row count ceiling" />
              <PolicyRow name="debugEnabled" value="false" reason="Debug off by default in production" />
              <PolicyRow name="wikiProxyEnabled" value="false" reason="Third-party proxy off by default" />
            </tbody>
          </table>
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Turn Budget Formula</h3>
        <div className="bg-gray-950 border border-gray-700 rounded-lg p-4 font-mono text-sm text-gray-300">
          <pre>{`actual_turn_budget = min(
    validated_user_request,    // Must be finite positive integer
    configured_batch_limit,    // maxTurnsPerBatch (default: 10)
    absolute_server_limit      // absoluteMaxTurns (default: 100)
)

// Client-provided number can NEVER disable the server-side ceiling.
// Rejects: turns=999999999, batchSize=Infinity, negative counts, NaN`}</pre>
        </div>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">Allowed KV Categories</h3>
        <div className="flex flex-wrap gap-2">
          {['food', 'booze', 'familiars', 'skills', 'trophies', 'tattoos', 'coolitems', 'mritems', 'hobocodes', 'info', 'disc-food', 'disc-cocktail', 'disc-meat', 'disc-misc', 'disc-smith'].map(cat => (
            <span key={cat} className="px-2 py-1 rounded bg-gray-800 border border-gray-700 text-xs font-mono text-gray-300">
              {cat}
            </span>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-3">
          Explicit allowlist — arbitrary "sanitized" category names are rejected.
        </p>
      </section>
    </div>
  );
}

// ─── Tests Tab ───────────────────────────────────────────────────────────────

function TestsTab({ testResults }: { testResults: { results: TestResult[]; passed: number; failed: number; total: number } | null }) {
  const [filter, setFilter] = useState<string>('all');
  
  if (!testResults) return <div className="text-gray-400">Running tests...</div>;
  
  const categories = [...new Set(testResults.results.map(r => r.category))];
  const filtered = filter === 'all' ? testResults.results : testResults.results.filter(r => r.category === filter);
  
  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Security Test Battery</h2>
        <div className="flex items-center gap-4 mb-6">
          <div className={`px-4 py-2 rounded-lg ${testResults.failed === 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
            <span className="text-2xl font-bold">{testResults.passed}</span>
            <span className="text-sm ml-1">/ {testResults.total} passed</span>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded text-xs ${filter === 'all' ? 'bg-gray-700 text-gray-200' : 'bg-gray-800 text-gray-500'}`}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3 py-1 rounded text-xs ${filter === cat ? 'bg-gray-700 text-gray-200' : 'bg-gray-800 text-gray-500'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="space-y-2">
        {filtered.map((result, i) => (
          <div
            key={i}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg border ${
              result.passed
                ? 'bg-gray-900/50 border-gray-800'
                : 'bg-red-500/5 border-red-500/30'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
              result.passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
            }`}>
              {result.passed ? '✓' : '✗'}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-sm text-gray-200">{result.name}</div>
              {!result.passed && result.error && (
                <div className="text-xs text-red-400 mt-1 font-mono">{result.error}</div>
              )}
            </div>
            <span className="text-xs text-gray-600 font-mono shrink-0">{result.category}</span>
          </div>
        ))}
      </section>
    </div>
  );
}

// ─── Report Tab ──────────────────────────────────────────────────────────────

function ReportTab({ testResults }: { testResults: { results: TestResult[]; passed: number; failed: number; total: number } | null }) {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-gray-100 mb-4">Implementation Report</h2>
      </section>

      <section className="bg-gray-900 border border-gray-800 rounded-xl p-6 font-mono text-sm space-y-6">
        <ReportSection title="PROVENANCE">
          <ReportLine label="Upstream examined" value="SolariteCelestial/KoL-worker" />
          <ReportLine label="Upstream commit" value="bbce317d78a1cbfbec980a4efabbd803684e3021" />
          <ReportLine label="Target branch" value="main" />
          <ReportLine label="License" value="None specified — behavior reimplemented" />
        </ReportSection>

        <ReportSection title="SECURITY CHANGES">
          <ReportLine label="Target URL validation" value="Hardened — explicit allowlist, no fallthrough" />
          <ReportLine label="Mutation method" value="POST required (was GET)" />
          <ReportLine label="CSRF protection" value="Origin + Sec-Fetch-Site + X-KoL-Action header" />
          <ReportLine label="Admin authentication" value="Authorization: Bearer (was ?key= in URL)" />
          <ReportLine label="Redirect handling" value="Manual validation per hop (was follow)" />
          <ReportLine label="Retry policy" value="No automatic retry — OUTCOME_UNKNOWN on timeout" />
          <ReportLine label="Debug endpoint" value="Disabled by default (was ?raw=1)" />
          <ReportLine label="Wiki proxy" value="Disabled by default (was hard-coded)" />
          <ReportLine label="CSP handling" value="Analyzed before modification" />
          <ReportLine label="Turn budget" value="min(user, batch_limit, absolute_limit)" />
          <ReportLine label="Choice memory" value="Composite key with option fingerprint" />
          <ReportLine label="Fight state" value="UNKNOWN for ambiguous states (not RESOLVED)" />
        </ReportSection>

        <ReportSection title="TRUST BOUNDARIES ENFORCED">
          <ReportLine label="Browser → Worker UI" value="No eval, textContent, safe DOM" />
          <ReportLine label="Read-only → KoL" value="GET only, no mutation" />
          <ReportLine label="Mutating → KoL" value="POST + CSRF + budget" />
          <ReportLine label="Admin → KV" value="Bearer auth + allowlist + size limits" />
          <ReportLine label="Worker → KoL" value="Host allowlist + HTTPS + redirect validation" />
          <ReportLine label="Worker → Wiki" value="No credentials forwarded" />
          <ReportLine label="Worker → KV" value="Category allowlist + no personalized data" />
        </ReportSection>

        <ReportSection title="CREDENTIAL-FLOW RESULT">
          <ReportLine label="Cookie destinations" value="Only allowed KoL hosts (structurally enforced)" />
          <ReportLine label="pwd destinations" value="Only allowed KoL hosts (validated before attachment)" />
          <ReportLine label="Admin secret handling" value="Authorization header only, never in URL/logs/responses" />
        </ReportSection>

        <ReportSection title="MUTATION CONTROLS">
          <ReportLine label="Method" value="POST required for all state-changing operations" />
          <ReportLine label="CSRF mechanism" value="Origin + Sec-Fetch-Site + X-KoL-Action custom header" />
          <ReportLine label="Turn limit" value="min(requested, 10, 100)" />
          <ReportLine label="Fight limit" value="30 rounds maximum" />
          <ReportLine label="Choice limit" value="10 depth maximum" />
          <ReportLine label="Redirect limit" value="5 hops maximum" />
          <ReportLine label="Timeout behavior" value="OUTCOME_UNKNOWN — no automatic retry" />
        </ReportSection>

        <ReportSection title="TESTS">
          <ReportLine label="Command" value="runAllTests() — in-browser execution" />
          <ReportLine label="Passed" value={testResults ? `${testResults.passed}` : '...'} />
          <ReportLine label="Failed" value={testResults ? `${testResults.failed}` : '...'} />
          <ReportLine label="Total" value={testResults ? `${testResults.total}` : '...'} />
        </ReportSection>

        <ReportSection title="ADVERSARIAL TESTS">
          <ReportLine label="Arbitrary-host cookie exfiltration" value="BLOCKED — host validated before credential attachment" />
          <ReportLine label="Malicious redirect" value="BLOCKED — each hop validated against allowlist" />
          <ReportLine label="Cross-origin mutation" value="BLOCKED — Origin + Sec-Fetch-Site + action header" />
          <ReportLine label="XSS payloads" value="BLOCKED — textContent used, no eval, safe DOM construction" />
          <ReportLine label="Admin-secret leakage" value="BLOCKED — Authorization header, never in URL/logs" />
          <ReportLine label="Timeout ambiguity" value="HANDLED — returns OUTCOME_UNKNOWN, no retry" />
        </ReportSection>

        <ReportSection title="LIVE KoL MUTATIONS">
          <div className="text-emerald-400 font-bold">NONE</div>
          <p className="text-gray-500 text-xs mt-1">No live KoL mutations were performed. All testing was offline.</p>
        </ReportSection>

        <div className="border-t border-gray-700 pt-4">
          <div className="text-emerald-400 font-bold text-base">DISPOSITION: SAFE_FOR_OFFLINE_USE</div>
          <p className="text-gray-500 text-xs mt-2">
            The useful KoL-worker behavior is implemented, authenticated credentials cannot escape their intended
            trust boundary, mutations are explicit and bounded, ambiguous actions are not retried, administrative
            secrets are protected, unknown game states stop rather than guess, and the claims are backed by
            executable tests.
          </p>
        </div>
      </section>
    </div>
  );
}

// ─── Shared Components ───────────────────────────────────────────────────────

function StatCard({ label, value, subtitle, color }: { label: string; value: string; subtitle: string; color: string }) {
  const colorClasses: Record<string, string> = {
    emerald: 'border-emerald-500/30 bg-emerald-500/5',
    blue: 'border-blue-500/30 bg-blue-500/5',
    purple: 'border-purple-500/30 bg-purple-500/5',
  };
  const textClasses: Record<string, string> = {
    emerald: 'text-emerald-400',
    blue: 'text-blue-400',
    purple: 'text-purple-400',
  };
  
  return (
    <div className={`rounded-xl border p-5 ${colorClasses[color] || colorClasses.emerald}`}>
      <div className={`text-3xl font-bold ${textClasses[color] || textClasses.emerald}`}>{value}</div>
      <div className="text-sm text-gray-300 mt-1">{label}</div>
      <div className="text-xs text-gray-500">{subtitle}</div>
    </div>
  );
}

function SecurityChange({ severity, title, description }: { severity: string; title: string; description: string }) {
  const colors: Record<string, string> = {
    critical: 'border-red-500/30 bg-red-500/5',
    high: 'border-orange-500/30 bg-orange-500/5',
    medium: 'border-yellow-500/30 bg-yellow-500/5',
  };
  const badges: Record<string, string> = {
    critical: 'bg-red-500/20 text-red-400',
    high: 'bg-orange-500/20 text-orange-400',
    medium: 'bg-yellow-500/20 text-yellow-400',
  };
  
  return (
    <div className={`rounded-lg border p-4 ${colors[severity] || colors.medium}`}>
      <div className="flex items-center gap-2 mb-1">
        <span className={`px-2 py-0.5 rounded text-xs font-medium ${badges[severity] || badges.medium}`}>
          {severity.toUpperCase()}
        </span>
        <span className="text-sm font-medium text-gray-200">{title}</span>
      </div>
      <p className="text-xs text-gray-400">{description}</p>
    </div>
  );
}

function ModuleCard({ name, description, exports, color }: { name: string; description: string; exports: string[]; color: string }) {
  const borderColors: Record<string, string> = {
    emerald: 'border-emerald-500/20',
    blue: 'border-blue-500/20',
    purple: 'border-purple-500/20',
    orange: 'border-orange-500/20',
    yellow: 'border-yellow-500/20',
    pink: 'border-pink-500/20',
    cyan: 'border-cyan-500/20',
  };
  
  return (
    <div className={`bg-gray-900 border rounded-lg p-4 ${borderColors[color] || 'border-gray-700'}`}>
      <div className="font-mono text-sm text-gray-200 mb-2">{name}</div>
      <p className="text-xs text-gray-400 mb-3">{description}</p>
      <div className="flex flex-wrap gap-1">
        {exports.map(exp => (
          <span key={exp} className="px-1.5 py-0.5 rounded bg-gray-800 text-xs font-mono text-gray-400">
            {exp}
          </span>
        ))}
      </div>
    </div>
  );
}

function TrustBoundary({ id, name, description, rules, color }: { id: string; name: string; description: string; rules: string[]; color: string }) {
  const bgColors: Record<string, string> = {
    blue: 'bg-blue-500/5 border-blue-500/20',
    emerald: 'bg-emerald-500/5 border-emerald-500/20',
    orange: 'bg-orange-500/5 border-orange-500/20',
    red: 'bg-red-500/5 border-red-500/20',
    purple: 'bg-purple-500/5 border-purple-500/20',
    cyan: 'bg-cyan-500/5 border-cyan-500/20',
    yellow: 'bg-yellow-500/5 border-yellow-500/20',
  };
  
  return (
    <div className={`rounded-lg border p-4 ${bgColors[color] || 'bg-gray-900 border-gray-700'}`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="font-mono text-xs text-gray-500">#{id}</span>
        <span className="text-sm font-medium text-gray-200">{name}</span>
      </div>
      <p className="text-xs text-gray-400 mb-3">{description}</p>
      <div className="space-y-1">
        {rules.map(rule => (
          <div key={rule} className="flex items-center gap-2 text-xs text-gray-500">
            <span className="text-gray-600">•</span>
            <span>{rule}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function PolicyRow({ name, value, reason }: { name: string; value: string; reason: string }) {
  return (
    <tr className="hover:bg-gray-800/30">
      <td className="px-4 py-2 font-mono text-xs text-gray-300">{name}</td>
      <td className="px-4 py-2 text-gray-200">{value}</td>
      <td className="px-4 py-2 text-gray-500 text-xs">{reason}</td>
    </tr>
  );
}

function ReportSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="text-emerald-400 font-bold text-xs tracking-wider mb-2">{title}</h4>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function ReportLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2 text-xs">
      <span className="text-gray-500 shrink-0 w-48">{label}:</span>
      <span className="text-gray-300">{value}</span>
    </div>
  );
}

export default App;
