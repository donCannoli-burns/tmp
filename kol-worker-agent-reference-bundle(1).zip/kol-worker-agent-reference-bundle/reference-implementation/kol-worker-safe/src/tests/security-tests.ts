import { DEFAULT_POLICY, validatePolicy, computeTurnBudget } from '../worker/policy';
import { validateKolUrl, validateAdventureTarget } from '../worker/host-policy';
import { safeKoLRequest, FetchFunction, resetFetchImplementation, setFetchImplementation } from '../worker/safe-request';
import { runAdventureBatch, resolveHumanChoice, choiceKey, isRetryableMutationError } from '../worker/adventure';
import { validateSeedRequest } from '../worker/kv-seed';
import { redactForLog, redactUrl } from '../worker/redact';
import { transformUpstreamSetCookie, extractKoLCookieHeader, CSRF_COOKIE } from '../worker/cookies';
import { buildAccountSnapshot, snapshotAccountPage, snapshotCategoryPage } from '../worker/snapshot';
import { autoAdventureScript, kvSeedScript, snapshotScript } from '../worker/ui';
import { extractZoneNum, searchWikiLocations } from '../worker/wiki';
import { copySafeResponseHeaders, cspAllowsSelfScript, rewriteHtml } from '../worker/rewrite';
import worker, { route, policyFromEnv } from '../worker/runtime';

type TestResult = { name:string; category:string; passed:boolean; error?:string };
const results:TestResult[]=[];
function assert(value:unknown,message='assertion failed'):asserts value { if(!value) throw new Error(message); }
function equal<T>(actual:T,expected:T,message='values differ'):void { if(actual!==expected) throw new Error(`${message}: expected=${String(expected)} actual=${String(actual)}`); }
async function test(name:string,category:string,fn:()=>void|Promise<void>):Promise<void>{try{await fn();results.push({name,category,passed:true})}catch(e){results.push({name,category,passed:false,error:(e as Error).message})}}
function response(body:string,status=200,headers:Record<string,string>={}):Response{return new Response(body,{status,headers})}
function header(init:RequestInit,key:string):string|null{return new Headers(init.headers||{}).get(key)}
function captureFetch(handler:(url:string,init:RequestInit,index:number)=>Response|Promise<Response>){
  const calls:Array<{url:string;init:RequestInit}>=[];
  const fetchFn:FetchFunction=async(url,init)=>{calls.push({url,init});return handler(url,init,calls.length-1)};
  return {calls,fetchFn};
}
function assertNoCredentialsToNonKoL(calls:Array<{url:string;init:RequestInit}>):void{
  for(const call of calls){
    const u=new URL(call.url);
    if(u.hostname==='www.kingdomofloathing.com'||u.hostname==='kingdomofloathing.com') continue;
    equal(header(call.init,'Cookie'),null,`Cookie escaped to ${u.hostname}`);
    const body=typeof call.init.body==='string'?call.init.body:'';
    assert(!u.searchParams.has('pwd'),`pwd query escaped to ${u.hostname}`);
    assert(!/(?:^|&)pwd=/.test(body),`pwd body escaped to ${u.hostname}`);
  }
}
function csrfHeaders(origin='https://worker.example',token='csrf-token-12345678'):Headers{
  return new Headers({Origin:origin,'Sec-Fetch-Site':'same-origin','X-KoL-Action':'mutate','X-KoL-CSRF':token,'X-KoL-Operation-Id':'operation-12345678',Cookie:`${CSRF_COOKIE}=${token}; kol_upstream_PHPSESSID=abc123`,'Content-Type':'application/json'});
}

async function main(){
  const policy=validatePolicy();

  await test('arbitrary target URL rejected','url',()=>{assert(!validateAdventureTarget('https://evil.example/adventure.php?snarfblat=1',policy).ok)});
  await test('host suffix confusion rejected','url',()=>{assert(!validateKolUrl('https://kingdomofloathing.com.evil.example/adventure.php?snarfblat=1',policy).ok)});
  await test('userinfo URL rejected','url',()=>{assert(!validateKolUrl('https://www.kingdomofloathing.com@evil.example/adventure.php?snarfblat=1',policy).ok)});
  await test('encoded hostname confusion rejected','url',()=>{assert(!validateKolUrl('https://www.kingdomofloathing.com%2eevil.example/adventure.php?snarfblat=1',policy).ok)});
  await test('malformed URL rejected','url',()=>{assert(!validateKolUrl('https://[broken',policy).ok)});
  await test('non-HTTPS authenticated target rejected','url',()=>{assert(!validateKolUrl('http://www.kingdomofloathing.com/adventure.php?snarfblat=1',policy).ok)});
  await test('unexpected adventure path rejected','url',()=>{assert(!validateAdventureTarget('https://www.kingdomofloathing.com/fight.php?snarfblat=1',policy).ok)});
  await test('invalid snarfblat rejected','url',()=>{assert(!validateAdventureTarget('https://www.kingdomofloathing.com/adventure.php?snarfblat=Infinity',policy).ok)});

  await test('attacker redirect is rejected without second request','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'https://evil.example/steal'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(c.calls.length,1,'attacker redirect caused second request');assertNoCredentialsToNonKoL(c.calls);
  });
  await test('direct attacker target receives zero requests','transport',async()=>{
    const c=captureFetch(()=>response('should not happen'));
    const r=await safeKoLRequest('https://evil.example/',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(!r.ok);equal(c.calls.length,0);
  });
  await test('session cookie never reaches attacker host','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'https://attacker.example/capture'}));
    await safeKoLRequest('https://www.kingdomofloathing.com/main.php',{cookie:'PHPSESSID=secret-cookie',policy,intent:'read'},c.fetchFn);
    assertNoCredentialsToNonKoL(c.calls);assert(!c.calls.some(x=>new URL(x.url).hostname==='attacker.example'));
  });
  await test('pwd never reaches attacker host','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'https://attacker.example/capture'}));
    await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef1234',{cookie:'PHPSESSID=secret-cookie',policy,intent:'mutation'},c.fetchFn);
    assertNoCredentialsToNonKoL(c.calls);assert(!c.calls.some(x=>new URL(x.url).hostname==='attacker.example'));
  });
  await test('KoL-to-KoL relative redirect is manually validated','transport',async()=>{
    const c=captureFetch((_u,_i,n)=>n===0?response('',302,{Location:'/main.php'}):response('ok'));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(r.ok);equal(c.calls.length,2);for(const x of c.calls)equal((x.init as {redirect?:string}).redirect,'manual');
  });
  await test('absolute valid KoL redirect is manually validated','transport',async()=>{
    const c=captureFetch((_u,_i,n)=>n===0?response('',302,{Location:'https://www.kingdomofloathing.com/main.php'}):response('ok'));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(r.ok);equal(c.calls.length,2);assertNoCredentialsToNonKoL(c.calls);
  });
  await test('authenticated read cannot redirect onto mutating KoL GET path','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'/adventure.php?snarfblat=1'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(!r.ok);equal(r.code,'REDIRECT_PATH_REJECTED');equal(c.calls.length,1,'read redirect issued a mutating second request');
  });
  await test('authenticated read primitive rejects direct mutating GET path','transport',async()=>{
    const c=captureFetch(()=>response('should not happen'));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(!r.ok);equal(r.code,'READ_PATH_REJECTED');equal(c.calls.length,0);
  });
  await test('malformed redirect location stops without second authenticated request','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'https://[broken'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy,intent:'read'},c.fetchFn);
    assert(!r.ok);equal(c.calls.length,1);
  });
  await test('redirect ceiling stops','transport',async()=>{
    const tiny=validatePolicy({...DEFAULT_POLICY,maxRedirects:1});
    const c=captureFetch((_u,_i,n)=>response('',302,{Location:`/main.php?hop=${n}`}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy:tiny,intent:'read'},c.fetchFn);
    assert(!r.ok);equal(r.code,'REDIRECT_LIMIT');equal(c.calls.length,2);
  });
  await test('login redirect stops authenticated request','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'/login.php'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/charpane.php',{cookie:'PHPSESSID=secret',policy,intent:'session'},c.fetchFn);
    assert(!r.ok);equal(r.code,'REDIRECT_VALIDATION_FAILED');equal(c.calls.length,1);
  });
  await test('mutation timeout/network failure is not retried','transport',async()=>{
    const c=captureFetch(()=>{throw new Error('timeout')});
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(r.code,'OUTCOME_UNKNOWN');equal(r.outcomeUnknown,true);equal(c.calls.length,1);equal(isRetryableMutationError(r.code),false);
  });
  await test('mutation HTTP 500 is outcome unknown and not counted complete','transport',async()=>{
    const c=captureFetch(()=>response('server error',500));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(r.code,'OUTCOME_UNKNOWN');equal(r.outcomeUnknown,true);equal(c.calls.length,1);
  });
  await test('mutation response body read failure is outcome unknown','transport',async()=>{
    const c=captureFetch(()=>({status:200,statusText:'OK',headers:new Headers(),text:async()=>{throw new Error('stream reset')}} as unknown as Response));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(r.code,'OUTCOME_UNKNOWN');equal(r.outcomeUnknown,true);equal(c.calls.length,1);
  });
  await test('mutation 307 is never replayed','transport',async()=>{
    const c=captureFetch(()=>response('',307,{Location:'/adventure.php?snarfblat=1'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{method:'POST',body:'x=1',cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(r.code,'OUTCOME_UNKNOWN');equal(c.calls.length,1);
  });
  await test('mutation redirect cannot spend a second adventure','transport',async()=>{
    const c=captureFetch(()=>response('',302,{Location:'/adventure.php?snarfblat=1'}));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(!r.ok);equal(r.code,'MUTATION_REDIRECT_REJECTED');equal(c.calls.length,1,'mutation redirect issued an extra adventure request');
  });
  await test('mutation redirect may enter fight readback','transport',async()=>{
    const c=captureFetch((_u,_i,n)=>n===0?response('',302,{Location:'/fight.php'}):response('fight state'));
    const r=await safeKoLRequest('https://www.kingdomofloathing.com/adventure.php?snarfblat=1&pwd=deadbeef',{cookie:'PHPSESSID=secret',policy,intent:'mutation'},c.fetchFn);
    assert(r.ok);equal(r.response.finalUrl.pathname,'/fight.php');equal(c.calls.length,2);equal(c.calls[1].init.method,'GET');
  });

  await test('oversized turn request is server bounded','budget',()=>{const b=computeTurnBudget(999999999,policy);equal(b.budget,policy.maxTurnsPerBatch);equal(b.clamped,true)});
  await test('negative turns rejected','budget',()=>{let ok=false;try{computeTurnBudget(-1,policy)}catch{ok=true}assert(ok)});
  await test('NaN turns rejected','budget',()=>{let ok=false;try{computeTurnBudget(Number.NaN,policy)}catch{ok=true}assert(ok)});
  await test('Infinity turns rejected','budget',()=>{let ok=false;try{computeTurnBudget(Number.POSITIVE_INFINITY,policy)}catch{ok=true}assert(ok)});
  await test('invalid security policy fails closed','budget',()=>{let ok=false;try{validatePolicy({...DEFAULT_POLICY,maxFightRounds:0})}catch{ok=true}assert(ok)});

  await test('unknown choice stops and does not submit','choice',async()=>{
    const html='<form><input name="whichchoice" value="123"><input name="option" value="1"><input type="submit" value="&lt;script&gt;bad&lt;/script&gt;"></form>';
    const c=captureFetch((url,_init)=>{
      const u=new URL(url);
      if(u.pathname==='/charpane.php')return response('<a href="x?pwd=deadbeef1234">x</a>');
      if(u.pathname==='/adventure.php')return response('',302,{Location:'/choice.php?whichchoice=123'});
      if(u.pathname==='/choice.php')return response(html);
      throw new Error('unexpected '+url);
    });
    const out=await runAdventureBatch({target:'https://www.kingdomofloathing.com/adventure.php?snarfblat=1',turns:1},'PHPSESSID=secret','https://worker.example',policy,c.fetchFn);
    equal(out.reason,'UNKNOWN_CHOICE');assert(!!out.unknownChoice);equal(out.unknownChoice!.options[0].label,'<script>bad</script>');equal(c.calls.filter(x=>x.init.method==='POST').length,0,'unknown choice was submitted');
  });
  await test('changed choice fingerprint stops before POST','choice',async()=>{
    const oldKey=choiceKey('777',[{option:'1',label:'Old label'}])!;
    const c=captureFetch((url,_init)=>{
      const u=new URL(url);
      if(u.pathname==='/charpane.php')return response('pwd=deadbeef1234');
      if(u.pathname==='/choice.php')return response('<form><input name="whichchoice" value="777"><input name="option" value="1"><input type="submit" value="Changed label"></form>');
      throw new Error('unexpected');
    });
    const r=await resolveHumanChoice({whichchoice:'777',option:'1',expectedKey:oldKey},'PHPSESSID=secret',policy,c.fetchFn);
    assert(!r.ok);equal(r.error,'CHOICE_FINGERPRINT_CHANGED');equal(c.calls.filter(x=>x.init.method==='POST').length,0);
  });
  await test('adventure HTTP failure never increments completed turn','budget',async()=>{
    const c=captureFetch((url)=>{const u=new URL(url);if(u.pathname==='/charpane.php')return response('pwd=deadbeef1234');if(u.pathname==='/adventure.php')return response('server error',500);throw new Error('unexpected')});
    const out=await runAdventureBatch({target:'https://www.kingdomofloathing.com/adventure.php?snarfblat=1',turns:1},'PHPSESSID=secret','https://worker.example',policy,c.fetchFn);
    equal(out.completed,0);equal(out.turnsIssued,1);equal(out.outcomeUnknown,true);equal(out.reason,'OUTCOME_UNKNOWN');equal(c.calls.filter(x=>new URL(x.url).pathname==='/adventure.php').length,1);
  });

  await test('fight round ceiling stops','fight',async()=>{
    const small=validatePolicy({...DEFAULT_POLICY,maxFightRounds:2,maxTurnsPerBatch:1});let fightPosts=0;
    const c=captureFetch((url,init)=>{const u=new URL(url);
      if(u.pathname==='/charpane.php')return response('pwd=deadbeef1234');
      if(u.pathname==='/adventure.php')return response('',302,{Location:'/fight.php'});
      if(u.pathname==='/fight.php'&&init.method==='GET')return response('fight round initial');
      if(u.pathname==='/fight.php'&&init.method==='POST'){fightPosts++;return response('fight round '+fightPosts)};
      throw new Error('unexpected');});
    const out=await runAdventureBatch({target:'https://www.kingdomofloathing.com/adventure.php?snarfblat=1',turns:1,macroId:'12'},'PHPSESSID=secret','https://worker.example',small,c.fetchFn);
    equal(out.reason,'FIGHT_ROUND_LIMIT');equal(fightPosts,2);
  });

  await test('invalid KV category rejected','admin',()=>{const r=validateSeedRequest({category:'../secrets',body:'a\tb',authHeader:'Bearer admin'},policy,'admin');assert(!r.ok)});
  await test('oversized KV upload rejected before commit','admin',()=>{const tiny=validatePolicy({...DEFAULT_POLICY,maxSeedBytes:4});const r=validateSeedRequest({category:'food',body:'12345',authHeader:'Bearer admin'},tiny,'admin');assert(!r.ok)});
  await test('wrong admin auth rejected','admin',()=>{const r=validateSeedRequest({category:'food',body:'a\tb',authHeader:'Bearer wrong'},policy,'admin');assert(!r.ok)});
  await test('admin secret redacted from logs and URLs','logging',()=>{const s='S3cr3tValue';assert(!redactForLog(`Authorization: Bearer ${s} pwd=deadbeef key=${s}`).includes(s));assert(!redactUrl(`https://worker.example/x?key=${s}&pwd=deadbeef`).includes(s))});
  await test('KV admin secret in query is rejected by runtime','admin',async()=>{
    const req=new Request('https://worker.example/api/kv-seed/food?key=S3cr3tValue',{method:'POST',headers:{Authorization:'Bearer S3cr3tValue',Origin:'https://worker.example','Sec-Fetch-Site':'same-origin'},body:'a\tb'});
    const r=await route(req,{KV_SEED_KEY:'S3cr3tValue'});equal(r.status,400);assert(!(await r.text()).includes('S3cr3tValue'));
  });
  await test('KV seed page does not place secret in URL or localStorage','admin',async()=>{const r=await route(new Request('https://worker.example/kv-seed'),{KV_SEED_KEY:'unused'});const t=await r.text(),js=kvSeedScript();assert(!t.includes('?key='));assert(!/localStorage\s*[.(]/.test(t+js));assert(js.includes('Authorization'));assert(t.includes('/ui/kv-seed.js'))});
  await test('cross-origin KV seed is rejected before commit','admin',async()=>{let puts=0;const kv={async get(){return null},async put(){puts++}};const r=await route(new Request('https://worker.example/api/kv-seed/food',{method:'POST',headers:{Authorization:'Bearer admin',Origin:'https://evil.example','Sec-Fetch-Site':'cross-site'},body:'a\tb'}),{KV_SEED_KEY:'admin',SNAPSHOT_KV:kv});equal(r.status,403);equal(puts,0)});

  await test('mutation over GET rejected','csrf',async()=>{const r=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'GET'}),{});equal(r.status,405)});
  await test('cross-origin mutation rejected','csrf',async()=>{
    const h=csrfHeaders('https://evil.example');
    const r=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:h,body:JSON.stringify({target:'/adventure.php?snarfblat=1',turns:1})}),{});equal(r.status,403);
  });
  await test('missing CSRF action proof rejected','csrf',async()=>{
    const h=csrfHeaders();h.delete('X-KoL-Action');
    const r=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:h,body:'{}'}),{});equal(r.status,403);
  });
  await test('missing CSRF token rejected','csrf',async()=>{
    const h=csrfHeaders();h.delete('X-KoL-CSRF');
    const r=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:h,body:'{}'}),{});equal(r.status,403);
  });
  await test('generic authenticated proxy mutation forbidden','csrf',async()=>{
    const r=await route(new Request('https://worker.example/_/www.kingdomofloathing.com/adventure.php?snarfblat=1',{method:'POST',headers:csrfHeaders(),body:'x=1'}),{});equal(r.status,405);assert((await r.text()).includes('GENERIC_PROXY_MUTATION_FORBIDDEN'));
  });
  await test('GET proxy cannot spend an adventure by URL substitution','csrf',async()=>{
    const r=await route(new Request('https://worker.example/_/www.kingdomofloathing.com/adventure.php?snarfblat=1',{method:'GET',headers:{Cookie:'kol_upstream_PHPSESSID=abc123'}}),{});
    equal(r.status,403);assert((await r.text()).includes('PROXY_PATH_NOT_READ_ONLY_ALLOWLISTED'));
  });
  await test('replayed operation id is rejected within one isolate','csrf',async()=>{
    let adventureCalls=0;
    setFetchImplementation(async(url)=>{const u=new URL(url);if(u.pathname==='/charpane.php')return response('pwd=deadbeef1234');if(u.pathname==='/adventure.php'){adventureCalls++;return response('ordinary page')}throw new Error('unexpected')});
    try{
      const h=csrfHeaders();h.set('X-KoL-Operation-Id','operation-replay-123');
      const body=JSON.stringify({target:'/adventure.php?snarfblat=1',turns:1});
      const r1=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:h,body}),{});equal(r1.status,200);
      const r2=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:h,body}),{});equal(r2.status,409);assert((await r2.text()).includes('DUPLICATE_OPERATION_ID'));equal(adventureCalls,1);
    } finally { resetFetchImplementation(); }
  });

  await test('same-session overlapping mutation is rejected within one isolate','csrf',async()=>{
    let releaseFirst:(r:Response)=>void=()=>{};let started:()=>void=()=>{};
    const startedP=new Promise<void>(r=>{started=r});
    const firstP=new Promise<Response>(r=>{releaseFirst=r});let calls=0;
    setFetchImplementation(async()=>{calls++;if(calls===1){started();return firstP}return response('ordinary page')});
    try{
      const make=(op:string)=>new Request('https://worker.example/api/auto-adventure/run',{method:'POST',headers:(()=>{const h=csrfHeaders();h.set('X-KoL-Operation-Id',op);return h})(),body:JSON.stringify({target:'/adventure.php?snarfblat=1',turns:1})});
      const p1=route(make('operation-first-123'),{});await startedP;
      const r2=await route(make('operation-second-123'),{});equal(r2.status,409);assert((await r2.text()).includes('MUTATION_ALREADY_IN_FLIGHT'));
      releaseFirst(response('pwd=deadbeef1234'));
      const r1=await p1;equal(r1.status,200);
    } finally { resetFetchImplementation(); }
  });
  await test('preflight does not grant permissive CORS','csrf',async()=>{const r=await route(new Request('https://worker.example/api/auto-adventure/run',{method:'OPTIONS',headers:{Origin:'https://evil.example'}}),{});equal(r.headers.get('Access-Control-Allow-Origin'),null)});

  await test('personalized status response is no-store and leaks no worker CSRF cookie upstream','privacy',async()=>{
    const c=captureFetch((url,init)=>{assert(new URL(url).hostname==='www.kingdomofloathing.com');equal(header(init,'Cookie'),'PHPSESSID=abc123');return response(JSON.stringify({spleenuse:3,spleenlimit:15,turns:42,level:13}),200,{'Content-Type':'application/json'})});
    setFetchImplementation(c.fetchFn);
    try{const req=new Request('https://worker.example/api/status',{headers:{Cookie:`kol_upstream_PHPSESSID=abc123; ${CSRF_COOKIE}=never-upstream`}});const r=await route(req,{});equal(r.status,200);assert((r.headers.get('Cache-Control')||'').includes('no-store'));equal(r.headers.get('Access-Control-Allow-Origin'),null)}finally{resetFetchImplementation()}
  });
  await test('only namespaced upstream cookies are sent to KoL','privacy',()=>{equal(extractKoLCookieHeader(`kol_upstream_PHPSESSID=abc; ${CSRF_COOKIE}=csrf; other=x`),'PHPSESSID=abc')});
  await test('upstream Set-Cookie is host-scoped secure HttpOnly SameSite','privacy',()=>{const c=transformUpstreamSetCookie('PHPSESSID=abc; Domain=.kingdomofloathing.com; Path=/foo; Secure; SameSite=None');assert(!!c);assert(c!.startsWith('kol_upstream_PHPSESSID=abc'));assert(c!.includes('Path=/'));assert(c!.includes('Secure'));assert(c!.includes('HttpOnly'));assert(c!.includes('SameSite=Lax'));assert(!c!.includes('Domain='))});

  await test('third-party wiki/public request receives no KoL credentials','wiki',async()=>{
    const external=validatePolicy({...DEFAULT_POLICY,wikiProxyEnabled:true,wikiProxyOrigin:'https://wiki-proxy.example'});
    const c=captureFetch((url,init)=>{equal(new URL(url).hostname,'wiki-proxy.example');equal(header(init,'Cookie'),null);equal(header(init,'Authorization'),null);return response(JSON.stringify({query:{search:[]}}),200,{'Content-Type':'application/json'})});
    await searchWikiLocations('The Sleazy Back Alley',external,c.fetchFn);assertNoCredentialsToNonKoL(c.calls);
  });
  await test('wiki proxy defaults OFF','wiki',()=>{equal(policy.wikiProxyEnabled,false);equal(policy.wikiOrigin,'https://wiki.kingdomofloathing.com')});
  await test('location search resolves Zone Num without forwarding credentials','wiki',async()=>{
    const c=captureFetch((url,init,n)=>{equal(header(init,'Cookie'),null);equal(header(init,'Authorization'),null);if(n===0)return response(JSON.stringify(['icy',['The Icy Peak'],[],[]]),200,{'Content-Type':'application/json'});return response('<table><tr><th>Zone Num</th><td>110</td></tr></table>')});
    const hits=await searchWikiLocations('icy',policy,c.fetchFn);equal(hits.length,1);equal(hits[0].snarfblat,'110');equal(extractZoneNum('<b>Zone Num</b> 226'),'226');assertNoCredentialsToNonKoL(c.calls);
  });

  await test('personalized familiar snapshot is transient and no-store','snapshot',async()=>{
    let puts=0;const kv={async get(key:string){equal(key,'data:familiars');return JSON.stringify({version:1,category:'familiars',rows:[['1','Mosquito','familiar1'],['2','Leprechaun','familiar2']]})},async put(){puts++}};
    const c=captureFetch((url,init)=>{equal(new URL(url).pathname,'/familiar.php');equal(header(init,'Cookie'),'PHPSESSID=abc');return response('<input name=newfam value=1>')});
    const data=await buildAccountSnapshot('familiars',kv,'PHPSESSID=abc',policy,c.fetchFn);assert(data.ok);equal(data.ownedCount,1);equal(data.owned[0].name,'Mosquito');equal(puts,0,'personalized HTML/result was persisted to KV');assertNoCredentialsToNonKoL(c.calls);
    setFetchImplementation(c.fetchFn);try{const r=await route(new Request('https://worker.example/snapshot/data/familiars',{headers:{Cookie:'kol_upstream_PHPSESSID=abc'}}),{SNAPSHOT_KV:kv});equal(r.status,200);assert((r.headers.get('Cache-Control')||'').includes('no-store'))}finally{resetFetchImplementation()}
  });
  await test('snapshot endpoint requires authenticated session','snapshot',async()=>{const r=await route(new Request('https://worker.example/snapshot/data/familiars'),{});equal(r.status,401)});
  await test('snapshot account page renders via external textContent-only script','xss',()=>{const t=snapshotAccountPage('familiars'),js=snapshotScript();assert(!/\.innerHTML\b/.test(t+js));assert(js.includes('textContent'));assert(t.includes('/snapshot/data/familiars'));assert(t.includes('/ui/snapshot.js'))});
  await test('snapshot output escapes hostile HTML/JS','xss',()=>{const t=snapshotCategoryPage('x<script>',[[`<img src=x onerror=alert(1)>`,`"><script>alert(1)</script>`]]);assert(!t.includes('<img src=x'));assert(!t.includes('<script>alert(1)</script>'));assert(t.includes('&lt;img'))});
  await test('privileged UI uses safe DOM construction','xss',()=>{const s=autoAdventureScript();assert(!/\beval\s*\(/.test(s));assert(!/new\s+Function\b/.test(s));assert(!/\.innerHTML\b/.test(s));assert(s.includes('textContent'));assert(!/https?:\/\//.test(s),'UI contains remote script/network URL')});
  await test('proxy preserves CSP/X-Frame-Options and drops transformed content encoding','headers',()=>{const h=copySafeResponseHeaders({'Content-Security-Policy':"script-src 'self'",'X-Frame-Options':'SAMEORIGIN','Content-Encoding':'gzip','Content-Length':'123'},true);equal(h.get('Content-Security-Policy'),"script-src 'self'");equal(h.get('X-Frame-Options'),'SAMEORIGIN');equal(h.get('Content-Encoding'),null);equal(h.get('Content-Length'),null);assert((h.get('Cache-Control')||'').includes('no-store'))});
  await test('CSP-aware injection does not weaken nonce-only policy','headers',()=>{const csp="default-src 'none'; script-src 'nonce-abc'";equal(cspAllowsSelfScript(csp),false);const out=rewriteHtml('<html><body>x</body></html>','https://www.kingdomofloathing.com/main.php',policy,false);assert(!out.includes('/ui/auto-adventure.js'))});
  await test('worker-generated privileged pages use restrictive CSP','headers',async()=>{for(const path of ['/auto-adventure','/kv-seed','/snapshot/familiars']){const r=await route(new Request('https://worker.example'+path),{});const csp=r.headers.get('Content-Security-Policy')||'';assert(csp.includes("default-src 'none'"));assert(csp.includes("script-src 'self'"));assert(!/script-src[^;]*'unsafe-inline'/.test(csp));assert((r.headers.get('X-Frame-Options')||'')==='DENY')}});
  await test('production debug configuration fails closed','debug',()=>{let ok=false;try{policyFromEnv({DEBUG:'true'})}catch{ok=true}assert(ok)});
  await test('raw/debug route is not exposed','debug',async()=>{const r=await worker.fetch(new Request('https://worker.example/raw?raw=1'),{});assert(r.status!==200||!(r.headers.get('Content-Type')||'').includes('text/plain'))});

  const failed=results.filter(r=>!r.passed);
  const byCategory:Record<string,{passed:number;failed:number}>={};
  for(const r of results){byCategory[r.category] ||= {passed:0,failed:0};byCategory[r.category][r.passed?'passed':'failed']++}
  console.log(JSON.stringify({total:results.length,passed:results.length-failed.length,failed:failed.length,byCategory,failures:failed},null,2));
  if(failed.length) throw new Error(`${failed.length} security test(s) failed`);
}

void main();
