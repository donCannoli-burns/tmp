import { PolicyConfig, computeTurnBudget } from './policy';
import { validateAdventureTarget, ValidatedKolUrl } from './host-policy';
import { safeKoLRequest, SafeKoLResponse, FetchFunction, OperationBudget, createOperationBudget } from './safe-request';

export interface AdventureRequest { target: string; turns: number; macroId?: string; knownChoices?: Record<string,string> }
export interface UnknownChoiceInfo { whichchoice: string | null; key: string | null; options: Array<{ option: string; label: string | null }>; viewUrl: string }
export interface AdventureOutcome {
  completed: number;
  remaining: number;
  stopped: boolean;
  reason: string | null;
  unknownChoice: UnknownChoiceInfo | null;
  log: string[];
  turnsIssued: number;
  upstreamRequests: number;
  outcomeUnknown: boolean;
}
export type FightOutcome =
  | { status:'RESOLVED'; rounds:number; summary:string }
  | { status:'STILL_IN_FIGHT'; rounds:number; summary:string }
  | { status:'SESSION_EXPIRED'; rounds:number }
  | { status:'UNKNOWN'; rounds:number; summary:string };

export const OUTCOME_UNKNOWN = 'OUTCOME_UNKNOWN';

export function extractAndValidateTarget(rawInput: string, workerOrigin: string, policy: PolicyConfig): {ok:true;url:ValidatedKolUrl}|{ok:false;error:string} {
  if (!rawInput || typeof rawInput !== 'string') return { ok:false, error:'TARGET_REQUIRED' };
  let candidate = rawInput.trim();
  if (candidate.startsWith('/_/')) {
    try {
      const proxy = new URL(candidate, workerOrigin);
      const m = proxy.pathname.match(/^\/_\/([^/]+)(\/.*)?$/);
      if (!m) return { ok:false, error:'INVALID_PROXY_URL' };
      candidate = `https://${m[1]}${m[2] || '/'}${proxy.search}`;
    } catch { return { ok:false, error:'INVALID_PROXY_URL' }; }
  } else if (candidate.startsWith('/')) {
    candidate = `https://${policy.canonicalKolHost}${candidate}`;
  }
  const result = validateAdventureTarget(candidate, policy);
  return result.ok ? { ok:true, url:result.url } : { ok:false, error:result.reason };
}

export function extractPwd(html: string): string | null {
  const patterns = [
    /(?:[?&]|\b)pwd=([a-fA-F0-9]{8,})/,
    /name=["']?pwd["']?\s+value=["']?([a-fA-F0-9]{8,})/i,
    /value=["']?([a-fA-F0-9]{8,})["']?\s+name=["']?pwd["']?/i,
  ];
  for (const p of patterns) { const m = html.match(p); if (m) return m[1]; }
  return null;
}
export function withPwd(targetUrl: string, pwd: string): string { const u = new URL(targetUrl); u.searchParams.set('pwd', pwd); return u.toString(); }

function decodeEntities(text: string): string {
  return text.replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
}
export function parseChoiceForms(body: string): Array<{option:string;whichchoice:string|null;label:string|null}> {
  const forms = body.match(/<form\b[^>]*>[\s\S]*?<\/form>/gi) || [];
  const out: Array<{option:string;whichchoice:string|null;label:string|null}> = [];
  for (const form of forms) {
    const option = form.match(/name=["']?option["']?[^>]*?value=["']?(\d+)["']?/i) || form.match(/value=["']?(\d+)["']?[^>]*?name=["']?option["']?/i);
    if (!option) continue;
    const which = form.match(/name=["']?whichchoice["']?[^>]*?value=["']?(\d+)["']?/i) || form.match(/value=["']?(\d+)["']?[^>]*?name=["']?whichchoice["']?/i);
    const submitTag = form.match(/<input\b[^>]*\btype=["']?submit["']?[^>]*>/i)?.[0] || null;
    const label = submitTag ? (submitTag.match(/\bvalue=["']([^"']*)["']/i) || submitTag.match(/\bvalue=([^\s>]+)/i)) : null;
    out.push({ option: option[1], whichchoice: which ? which[1] : null, label: label ? decodeEntities(label[1].trim()) : null });
  }
  return out;
}
export function choiceKey(whichchoice: string | null, options: Array<{label:string|null;option:string}>): string | null {
  if (!whichchoice) return null;
  const fingerprint = options.map(o => `${o.option}:${(o.label || '').trim()}`).sort().join('|');
  return `${whichchoice}::${fingerprint}`;
}

export function classifyFightState(responseBody:string,responseUrl:string,previousBody:string|null,round:number,maxRounds:number):FightOutcome {
  let p: string;
  try { p = new URL(responseUrl).pathname; } catch { return { status:'UNKNOWN', rounds:round+1, summary:'invalid response URL' }; }
  if (p === '/login.php' || /Bad password|login\.php/i.test(responseBody)) return { status:'SESSION_EXPIRED', rounds:round+1 };
  if (p !== '/fight.php' && p !== '/fambattle.php') return { status:'RESOLVED', rounds:round+1, summary:`left fight page after ${round+1} round(s)` };
  if (/You win the fight|WINWINWIN/i.test(responseBody)) return { status:'RESOLVED', rounds:round+1, summary:`victory marker after ${round+1} round(s)` };
  if (previousBody !== null && responseBody === previousBody) return { status:'UNKNOWN', rounds:round+1, summary:'identical fight response; state uncertain' };
  if (round >= maxRounds - 1) return { status:'STILL_IN_FIGHT', rounds:round+1, summary:'fight round ceiling reached' };
  return { status:'STILL_IN_FIGHT', rounds:round+1, summary:`fight continues (round ${round+1})` };
}

export function isRetryableMutationError(_errorCode:string):boolean { return false; }
export function handleMutationTimeout(): {error:string;code:string} { return { error:'Request timed out — outcome unknown. Do not retry without refreshing state first.', code:OUTCOME_UNKNOWN }; }

async function fetchPwd(cookie:string, policy:PolicyConfig, budget:OperationBudget, fetchFn?:FetchFunction, signal?:AbortSignal):Promise<{ok:true;pwd:string}|{ok:false;error:string}> {
  for (const path of ['/charpane.php','/main.php']) {
    const res = await safeKoLRequest(`https://${policy.canonicalKolHost}${path}`, { cookie, policy, intent:'read', budget, signal }, fetchFn);
    if (!res.ok) return { ok:false, error:res.code };
    const pwd = extractPwd(res.response.body);
    if (pwd) return { ok:true, pwd };
  }
  return { ok:false, error:'PWD_NOT_FOUND' };
}

function choiceInfo(response:SafeKoLResponse):UnknownChoiceInfo {
  const forms = parseChoiceForms(response.body);
  const ids = forms.map(f=>f.whichchoice).filter((x):x is string=>!!x);
  const unique = [...new Set(ids)];
  const urlId = new URL(response.finalUrl.href).searchParams.get('whichchoice');
  const which = urlId || (unique.length === 1 ? unique[0] : null);
  const options = forms.map(f=>({ option:f.option, label:f.label }));
  return { whichchoice:which, key:choiceKey(which,options), options, viewUrl: which ? `/_/${response.finalUrl.hostname}/choice.php?whichchoice=${encodeURIComponent(which)}` : `/_/${response.finalUrl.hostname}/choice.php` };
}

async function submitChoice(which:string, option:string, pwd:string, cookie:string, policy:PolicyConfig, budget:OperationBudget, fetchFn?:FetchFunction, signal?:AbortSignal) {
  const body = new URLSearchParams({ whichchoice:which, option, pwd });
  return safeKoLRequest(`https://${policy.canonicalKolHost}/choice.php`, { method:'POST', body, headers:{'Content-Type':'application/x-www-form-urlencoded'}, cookie, policy, intent:'mutation', budget, signal }, fetchFn);
}

async function resolveChoiceChain(initial:SafeKoLResponse,pwd:string,cookie:string,known:Record<string,string>,policy:PolicyConfig,budget:OperationBudget,fetchFn?:FetchFunction,signal?:AbortSignal):Promise<{kind:'normal';response:SafeKoLResponse}|{kind:'fight';response:SafeKoLResponse}|{kind:'unknown';info:UnknownChoiceInfo;response:SafeKoLResponse}|{kind:'error';code:string;unknown:boolean}> {
  let current = initial;
  for (let depth=0; depth<=policy.maxChoiceDepth; depth++) {
    const path = current.finalUrl.pathname;
    if (path === '/login.php') return { kind:'error', code:'SESSION_EXPIRED', unknown:false };
    if (path === '/fight.php' || path === '/fambattle.php') return { kind:'fight', response:current };
    if (path !== '/choice.php') return { kind:'normal', response:current };
    if (depth >= policy.maxChoiceDepth) return { kind:'error', code:'CHOICE_DEPTH_LIMIT', unknown:false };
    const info = choiceInfo(current);
    if (!info.whichchoice || !info.key || info.options.length === 0) return { kind:'unknown', info, response:current };
    const remembered = known[info.key];
    if (!remembered || !info.options.some(o=>o.option===remembered)) return { kind:'unknown', info, response:current };
    const submitted = await submitChoice(info.whichchoice, remembered, pwd, cookie, policy, budget, fetchFn, signal);
    if (!submitted.ok) return { kind:'error', code:submitted.code, unknown:!!submitted.outcomeUnknown };
    current = submitted.response;
  }
  return { kind:'error', code:'CHOICE_DEPTH_LIMIT', unknown:false };
}

async function resolveFight(initial:SafeKoLResponse,pwd:string,cookie:string,macroId:string|undefined,policy:PolicyConfig,budget:OperationBudget,fetchFn?:FetchFunction,signal?:AbortSignal):Promise<{ok:true;response:SafeKoLResponse;rounds:number}|{ok:false;code:string;unknown:boolean;rounds:number}> {
  if (macroId && !/^\d{1,9}$/.test(macroId)) return { ok:false, code:'INVALID_MACRO_ID', unknown:false, rounds:0 };
  let current = initial;
  let previous: string | null = null;
  for (let round=0; round<policy.maxFightRounds; round++) {
    const before = classifyFightState(current.body,current.finalUrl.href,previous,round,policy.maxFightRounds);
    if (before.status === 'RESOLVED') return { ok:true, response:current, rounds:round };
    if (before.status === 'SESSION_EXPIRED') return { ok:false, code:'SESSION_EXPIRED', unknown:false, rounds:round };
    if (before.status === 'UNKNOWN') return { ok:false, code:'FIGHT_STATE_UNKNOWN', unknown:true, rounds:round };
    previous = current.body;
    const body = new URLSearchParams({ action:'macro', pwd });
    if (macroId) body.set('whichmacro',macroId);
    const next = await safeKoLRequest(`https://${policy.canonicalKolHost}/fight.php`, { method:'POST', body, headers:{'Content-Type':'application/x-www-form-urlencoded'}, cookie, policy, intent:'mutation', budget, signal }, fetchFn);
    if (!next.ok) return { ok:false, code:next.code, unknown:!!next.outcomeUnknown, rounds:round+1 };
    current = next.response;
  }
  return { ok:false, code:'FIGHT_ROUND_LIMIT', unknown:false, rounds:policy.maxFightRounds };
}

export async function runAdventureBatch(request:AdventureRequest, cookie:string, workerOrigin:string, policy:PolicyConfig, fetchFn?:FetchFunction):Promise<AdventureOutcome> {
  const target = extractAndValidateTarget(request.target,workerOrigin,policy);
  if (!target.ok) throw new Error(target.error);
  const { budget:turnBudget } = computeTurnBudget(request.turns,policy);
  const known = request.knownChoices || {};
  const budget = createOperationBudget(policy.maxUpstreamRequests);
  const controller = new AbortController();
  const overall = setTimeout(()=>controller.abort(),policy.totalOperationTimeoutMs);
  const log:string[] = [];
  let completed=0, turnsIssued=0, outcomeUnknown=false;
  let unknownChoice:UnknownChoiceInfo|null=null;
  let reason:string|null=null;
  try {
    const pwdResult = await fetchPwd(cookie,policy,budget,fetchFn,controller.signal);
    if (!pwdResult.ok) return { completed:0, remaining:turnBudget, stopped:true, reason:pwdResult.error, unknownChoice:null, log, turnsIssued:0, upstreamRequests:budget.used, outcomeUnknown:false };
    const pwd = pwdResult.pwd;
    for (let i=0;i<turnBudget;i++) {
      const adventure = await safeKoLRequest(withPwd(target.url.href,pwd), { cookie, policy, intent:'mutation', budget, signal:controller.signal }, fetchFn);
      turnsIssued += 1;
      if (!adventure.ok) {
        outcomeUnknown = !!adventure.outcomeUnknown;
        reason = adventure.code;
        log.push(`turn ${i+1}: stopped (${adventure.code})`);
        break;
      }
      let chain = await resolveChoiceChain(adventure.response,pwd,cookie,known,policy,budget,fetchFn,controller.signal);
      if (chain.kind === 'unknown') { unknownChoice=chain.info; reason='UNKNOWN_CHOICE'; log.push(`turn ${i+1}: unknown choice; human selection required`); break; }
      if (chain.kind === 'error') { outcomeUnknown=chain.unknown; reason=chain.code; log.push(`turn ${i+1}: stopped (${chain.code})`); break; }
      if (chain.kind === 'fight') {
        const fight = await resolveFight(chain.response,pwd,cookie,request.macroId,policy,budget,fetchFn,controller.signal);
        if (!fight.ok) { outcomeUnknown=fight.unknown; reason=fight.code; log.push(`turn ${i+1}: fight stopped (${fight.code})`); break; }
        chain = await resolveChoiceChain(fight.response,pwd,cookie,known,policy,budget,fetchFn,controller.signal);
        if (chain.kind === 'unknown') { unknownChoice=chain.info; reason='UNKNOWN_CHOICE'; log.push(`turn ${i+1}: post-fight unknown choice`); break; }
        if (chain.kind === 'error' || chain.kind === 'fight') { reason=chain.kind === 'error' ? chain.code : 'FIGHT_CHAIN_UNEXPECTED'; outcomeUnknown=chain.kind === 'error' ? chain.unknown : true; break; }
      }
      completed += 1;
      log.push(`turn ${i+1}: resolved`);
    }
  } finally { clearTimeout(overall); }
  return { completed, remaining:Math.max(0,turnBudget-completed), stopped:completed<turnBudget, reason, unknownChoice, log, turnsIssued, upstreamRequests:budget.used, outcomeUnknown };
}

/** Human choice resolution re-reads the current choice and binds option to fingerprint. */
export async function resolveHumanChoice(input:{whichchoice:string;option:string;expectedKey:string}, cookie:string, policy:PolicyConfig, fetchFn?:FetchFunction):Promise<{ok:true;responsePath:string}|{ok:false;error:string;outcomeUnknown?:boolean}> {
  if (!/^\d{1,9}$/.test(input.whichchoice) || !/^\d{1,9}$/.test(input.option) || input.expectedKey.length > 4096) return { ok:false,error:'INVALID_CHOICE_INPUT' };
  const budget=createOperationBudget(Math.min(policy.maxUpstreamRequests,8));
  const pwdResult=await fetchPwd(cookie,policy,budget,fetchFn);
  if (!pwdResult.ok) return {ok:false,error:pwdResult.error};
  const current=await safeKoLRequest(`https://${policy.canonicalKolHost}/choice.php?whichchoice=${encodeURIComponent(input.whichchoice)}`,{cookie,policy,intent:'read',budget},fetchFn);
  if (!current.ok) return {ok:false,error:current.code};
  const info=choiceInfo(current.response);
  if (info.whichchoice!==input.whichchoice || info.key!==input.expectedKey) return {ok:false,error:'CHOICE_FINGERPRINT_CHANGED'};
  if (!info.options.some(o=>o.option===input.option)) return {ok:false,error:'CHOICE_OPTION_NOT_PRESENT'};
  const submitted=await submitChoice(input.whichchoice,input.option,pwdResult.pwd,cookie,policy,budget,fetchFn);
  if (!submitted.ok) return {ok:false,error:submitted.code,outcomeUnknown:!!submitted.outcomeUnknown};
  return {ok:true,responsePath:submitted.response.finalUrl.pathname};
}
