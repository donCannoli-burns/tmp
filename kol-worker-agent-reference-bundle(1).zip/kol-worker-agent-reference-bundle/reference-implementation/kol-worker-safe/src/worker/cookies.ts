/** Browser/KoL cookie boundary. Only explicitly prefixed browser cookies are sent upstream. */
export const UPSTREAM_COOKIE_PREFIX = 'kol_upstream_';
export const CSRF_COOKIE = 'kol_worker_csrf';

function safeCookieName(name: string): boolean { return /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name); }

export function parseCookieHeader(header: string): Array<[string, string]> {
  const out: Array<[string, string]> = [];
  for (const piece of (header || '').split(';')) {
    const idx = piece.indexOf('=');
    if (idx <= 0) continue;
    const name = piece.slice(0, idx).trim();
    const value = piece.slice(idx + 1).trim();
    if (safeCookieName(name) && !/[\r\n]/.test(value)) out.push([name, value]);
  }
  return out;
}

export function extractKoLCookieHeader(browserCookieHeader: string): string {
  return parseCookieHeader(browserCookieHeader)
    .filter(([name]) => name.startsWith(UPSTREAM_COOKIE_PREFIX))
    .map(([name, value]) => `${name.slice(UPSTREAM_COOKIE_PREFIX.length)}=${value}`)
    .join('; ');
}

export function getCookieValue(header: string, name: string): string | null {
  return parseCookieHeader(header).find(([n]) => n === name)?.[1] ?? null;
}

export function transformUpstreamSetCookie(raw: string): string | null {
  if (!raw || /[\r\n]/.test(raw)) return null;
  const parts = raw.split(';').map(x => x.trim()).filter(Boolean);
  if (!parts.length) return null;
  const firstEq = parts[0].indexOf('=');
  if (firstEq <= 0) return null;
  const name = parts[0].slice(0, firstEq).trim();
  const value = parts[0].slice(firstEq + 1);
  if (!safeCookieName(name)) return null;

  const retained: string[] = [];
  for (const attr of parts.slice(1)) {
    const lower = attr.toLowerCase();
    if (lower.startsWith('domain=') || lower.startsWith('path=') || lower.startsWith('samesite=') || lower === 'secure' || lower === 'httponly') continue;
    if (lower.startsWith('expires=') || lower.startsWith('max-age=')) retained.push(attr);
  }
  return `${UPSTREAM_COOKIE_PREFIX}${name}=${value}; Path=/; Secure; HttpOnly; SameSite=Lax${retained.length ? '; ' + retained.join('; ') : ''}`;
}

/** Handles runtimes with Headers.getSetCookie() and the common single-header fallback. */
export function readSetCookieHeaders(headers: Headers): string[] {
  const richer = headers as Headers & { getSetCookie?: () => string[] };
  if (typeof richer.getSetCookie === 'function') return richer.getSetCookie();
  const one = headers.get('set-cookie');
  return one ? [one] : [];
}

export function newCsrfToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

export function csrfCookieHeader(token: string): string {
  return `${CSRF_COOKIE}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=3600`;
}
