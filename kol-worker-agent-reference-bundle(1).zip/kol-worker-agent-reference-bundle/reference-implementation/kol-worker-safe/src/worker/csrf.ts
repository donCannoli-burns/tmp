import { CSRF_COOKIE, getCookieValue } from './cookies';

export interface CsrfValidationResult { ok: boolean; reason?: string }

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let v = 0;
  for (let i = 0; i < a.length; i++) v |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return v === 0;
}

/** Legacy-compatible guard: strict POST/origin/fetch-site/action proof. */
export function validateCsrf(method: string, headers: Headers, workerOrigin: string): CsrfValidationResult {
  if (method.toUpperCase() !== 'POST') return { ok: false, reason: 'MUTATION_REQUIRES_POST' };
  const origin = headers.get('Origin');
  if (!origin) return { ok: false, reason: 'ORIGIN_REQUIRED' };
  if (origin !== workerOrigin) return { ok: false, reason: 'ORIGIN_MISMATCH' };
  const fetchSite = headers.get('Sec-Fetch-Site');
  if (fetchSite && fetchSite !== 'same-origin') return { ok: false, reason: 'FETCH_SITE_NOT_SAME_ORIGIN' };
  if (headers.get('X-KoL-Action') !== 'mutate') return { ok: false, reason: 'MISSING_ACTION_HEADER' };
  return { ok: true };
}

export function validateMutationCsrf(request: Request, workerOrigin: string): CsrfValidationResult {
  const base = validateCsrf(request.method, request.headers, workerOrigin);
  if (!base.ok) return base;
  const cookieToken = getCookieValue(request.headers.get('Cookie') || '', CSRF_COOKIE);
  const headerToken = request.headers.get('X-KoL-CSRF');
  if (!cookieToken || !headerToken) return { ok: false, reason: 'CSRF_TOKEN_REQUIRED' };
  if (!constantTimeEqual(cookieToken, headerToken)) return { ok: false, reason: 'CSRF_TOKEN_MISMATCH' };
  return { ok: true };
}

export function restrictiveCorsHeaders(workerOrigin: string): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': workerOrigin,
    'Access-Control-Allow-Methods': 'POST',
    'Access-Control-Allow-Headers': 'Content-Type, X-KoL-Action, X-KoL-CSRF, X-KoL-Operation-Id',
    'Access-Control-Allow-Credentials': 'true',
    'Vary': 'Origin',
  };
}

export function noStoreHeaders(): Record<string, string> {
  return { 'Cache-Control': 'no-store, no-cache, must-revalidate, private', 'Pragma': 'no-cache' };
}
