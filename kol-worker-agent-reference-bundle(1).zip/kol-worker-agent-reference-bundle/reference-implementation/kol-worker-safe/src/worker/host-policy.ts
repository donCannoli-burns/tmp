import { PolicyConfig } from './policy';

export interface ValidatedKolUrl {
  readonly href: string;
  readonly hostname: string;
  readonly pathname: string;
  readonly search: string;
  readonly hash: string;
  readonly isKolHost: true;
}
export type UrlValidationResult = { ok: true; url: ValidatedKolUrl } | { ok: false; reason: string };

export function isAllowedKolHost(hostname: string, policy: PolicyConfig): boolean {
  const h = hostname.toLowerCase().trim();
  if (!h || h === 'localhost' || h === '::1' || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(h) || h.includes(':')) return false;
  return policy.allowedKolHosts.includes(h);
}

export function rejectHostConfusion(hostname: string): boolean {
  const h = hostname.toLowerCase().trim();
  if (!h || h.includes('@') || /%2e/i.test(h) || h === 'localhost' || h === '::1') return false;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(h) || h.includes(':')) return false;
  return true;
}

export function validateKolUrl(raw: string, policy: PolicyConfig): UrlValidationResult {
  if (!raw || typeof raw !== 'string') return { ok: false, reason: 'URL_REQUIRED' };
  const lower = raw.trim().toLowerCase();
  if (/^(javascript|data|file|vbscript):/.test(lower)) return { ok: false, reason: 'DANGEROUS_SCHEME_REJECTED' };
  let parsed: URL;
  try { parsed = new URL(raw.trim().startsWith('//') ? `https:${raw.trim()}` : raw.trim()); }
  catch { return { ok: false, reason: 'INVALID_URL_PARSE' }; }
  if (parsed.protocol !== 'https:') return { ok: false, reason: 'NON_HTTPS_REJECTED' };
  if (parsed.username || parsed.password) return { ok: false, reason: 'USERINFO_IN_URL_REJECTED' };
  if (!rejectHostConfusion(parsed.hostname)) return { ok: false, reason: 'HOST_CONFUSION_REJECTED' };
  if (!isAllowedKolHost(parsed.hostname, policy)) return { ok: false, reason: `HOST_NOT_ALLOWED: ${parsed.hostname}` };
  return { ok: true, url: Object.freeze({ href: parsed.href, hostname: parsed.hostname, pathname: parsed.pathname, search: parsed.search, hash: parsed.hash, isKolHost: true as const }) };
}

export function validateAdventureTarget(raw: string, policy: PolicyConfig): UrlValidationResult {
  const base = validateKolUrl(raw, policy);
  if (!base.ok) return base;
  if (base.url.hostname !== policy.canonicalKolHost) return { ok: false, reason: 'ADVENTURE_HOST_NOT_CANONICAL' };
  if (!policy.allowedAdventurePaths.includes(base.url.pathname)) return { ok: false, reason: `INVALID_ADVENTURE_PATH: ${base.url.pathname}` };
  const u = new URL(base.url.href);
  const id = u.searchParams.get('snarfblat');
  if (!id || !/^\d{1,9}$/.test(id) || Number(id) < 1) return { ok: false, reason: 'INVALID_SNARFBLAT' };
  return base;
}

export interface DecodedProxyPath { host: string; path: string }
export function decodeProxyPath(pathname: string): DecodedProxyPath | null {
  const match = pathname.match(/^\/_\/([^/]+)(\/.*)?$/);
  if (!match) return null;
  if (!match[1] || match[1].includes('/') || match[1].includes('\\')) return null;
  return { host: match[1], path: match[2] || '/' };
}

export interface RedirectValidation { ok: boolean; reason?: string; validatedUrl?: ValidatedKolUrl }
export function validateRedirectLocation(location: string, baseUrl: string, policy: PolicyConfig): RedirectValidation {
  if (!location || typeof location !== 'string') return { ok: false, reason: 'EMPTY_LOCATION' };
  let resolved: URL;
  try { resolved = new URL(location, baseUrl); } catch { return { ok: false, reason: 'INVALID_LOCATION_URL' }; }
  const validated = validateKolUrl(resolved.toString(), policy);
  if (!validated.ok) {
    const host = (() => { try { return resolved.hostname; } catch { return 'invalid'; } })();
    if (!isAllowedKolHost(host, policy)) return { ok: false, reason: `REDIRECT_TO_NON_KOL: ${host}` };
    return { ok: false, reason: `REDIRECT_INVALID: ${validated.reason}` };
  }
  if (validated.url.pathname === '/login.php') return { ok: false, reason: 'SESSION_EXPIRED_LOGIN_REDIRECT' };
  return { ok: true, validatedUrl: validated.url };
}
