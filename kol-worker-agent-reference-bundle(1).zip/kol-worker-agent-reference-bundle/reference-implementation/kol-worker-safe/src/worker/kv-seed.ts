import { PolicyConfig } from './policy';

export interface KvSeedRequest { category:string; body:string; authHeader:string|null }
export interface KvSeedResult { ok:boolean; error?:string; category?:string; rows?:number }

function constantTimeEqual(a:string,b:string):boolean {
  const max=Math.max(a.length,b.length); let diff=a.length^b.length;
  for(let i=0;i<max;i++) diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);
  return diff===0;
}

export function validateAdminAuth(authHeader:string|null, expectedSecret:string):{ok:boolean;reason?:string} {
  if (!expectedSecret) return {ok:false,reason:'ADMIN_SECRET_NOT_CONFIGURED'};
  if (!authHeader) return {ok:false,reason:'MISSING_AUTH_HEADER'};
  const match=authHeader.match(/^Bearer\s+([^\s]+)$/i);
  if(!match)return {ok:false,reason:'INVALID_AUTH_FORMAT'};
  return constantTimeEqual(match[1],expectedSecret)?{ok:true}:{ok:false,reason:'AUTH_FAILED'};
}

export function validateCategory(rawCategory:string,policy:PolicyConfig):{ok:boolean;category?:string;reason?:string} {
  if(!rawCategory||typeof rawCategory!=='string')return{ok:false,reason:'CATEGORY_REQUIRED'};
  const category=rawCategory.toLowerCase().trim();
  return policy.allowedKvCategories.includes(category)?{ok:true,category}:{ok:false,reason:`CATEGORY_NOT_ALLOWED: ${category}`};
}

export function validateSeedInput(body:string,policy:PolicyConfig):{ok:boolean;rows?:string[][];reason?:string} {
  if(typeof body!=='string')return{ok:false,reason:'BODY_REQUIRED'};
  const bytes=new TextEncoder().encode(body).length;
  if(bytes>policy.maxSeedBytes)return{ok:false,reason:`UPLOAD_TOO_LARGE: ${bytes}`};
  if(body.includes('\u0000')||body.includes('\uFFFD'))return{ok:false,reason:'INVALID_TEXT_ENCODING'};
  const lines=body.split(/\r?\n/).filter(line=>line.trim().length>0);
  if(!lines.length)return{ok:false,reason:'EMPTY_UPLOAD'};
  if(lines.length>policy.maxSeedRows)return{ok:false,reason:`TOO_MANY_ROWS: ${lines.length}`};
  const rows:string[][]=[];
  for(let i=0;i<lines.length;i++){
    const fields=lines[i].split('\t');
    if(fields.length>policy.maxSeedColumns)return{ok:false,reason:`TOO_MANY_COLUMNS in row ${i+1}: ${fields.length}`};
    for(const field of fields)if(field.length>policy.maxSeedFieldLength)return{ok:false,reason:`FIELD_TOO_LONG in row ${i+1}: ${field.length}`};
    rows.push(fields);
  }
  return{ok:true,rows};
}

export function validateSeedRequest(request:KvSeedRequest,policy:PolicyConfig,expectedSecret:string):{ok:true;category:string;rows:string[][]}|{ok:false;error:string} {
  const auth=validateAdminAuth(request.authHeader,expectedSecret); if(!auth.ok)return{ok:false,error:auth.reason||'AUTH_FAILED'};
  const cat=validateCategory(request.category,policy); if(!cat.ok)return{ok:false,error:cat.reason||'INVALID_CATEGORY'};
  const input=validateSeedInput(request.body,policy); if(!input.ok)return{ok:false,error:input.reason||'INVALID_INPUT'};
  return{ok:true,category:cat.category!,rows:input.rows!};
}
