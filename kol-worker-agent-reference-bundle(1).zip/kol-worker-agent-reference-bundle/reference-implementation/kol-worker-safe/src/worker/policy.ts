/** Central security policy. Security-sensitive callers receive a validated object. */
export interface PolicyConfig {
  readonly allowedKolHosts: readonly string[];
  readonly canonicalKolHost: string;
  readonly allowedAdventurePaths: readonly string[];
  readonly allowedProxyReadPaths: readonly string[];
  readonly allowedAuthenticatedReadPaths: readonly string[];
  readonly allowedMutationRedirectReadPaths: readonly string[];
  readonly maxTurnsPerBatch: number;
  readonly absoluteMaxTurns: number;
  readonly maxFightRounds: number;
  readonly maxChoiceDepth: number;
  readonly maxRedirects: number;
  readonly maxUpstreamRequests: number;
  readonly upstreamTimeoutMs: number;
  readonly totalOperationTimeoutMs: number;
  readonly maxMutationBodyBytes: number;
  readonly recentOperationTtlMs: number;
  readonly maxRecentOperations: number;
  readonly maxSeedBytes: number;
  readonly maxSeedRows: number;
  readonly maxSeedColumns: number;
  readonly maxSeedFieldLength: number;
  readonly allowedKvCategories: readonly string[];
  readonly debugEnabled: boolean;
  readonly wikiOrigin: string;
  readonly wikiProxyEnabled: boolean;
  readonly wikiProxyOrigin: string;
}

export const DEFAULT_POLICY: PolicyConfig = Object.freeze({
  allowedKolHosts: ['www.kingdomofloathing.com', 'kingdomofloathing.com'] as const,
  canonicalKolHost: 'www.kingdomofloathing.com',
  allowedAdventurePaths: ['/adventure.php'] as const,
  allowedProxyReadPaths: [
    '/', '/main.php', '/charpane.php', '/charsheet.php', '/familiar.php',
    '/showconsumption.php', '/questlog.php', '/inventory.php', '/skills.php',
    '/effects.php', '/api.php', '/showplayer.php', '/desc_item.php',
    '/desc_skill.php', '/desc_effect.php', '/login.php'
  ] as const,
  // Superset used only by typed internal read operations. This prevents a
  // harmless read from following an authenticated redirect onto a mutating
  // KoL GET surface such as adventure.php.
  allowedAuthenticatedReadPaths: [
    '/', '/main.php', '/charpane.php', '/charsheet.php', '/familiar.php',
    '/showconsumption.php', '/questlog.php', '/inventory.php', '/skills.php',
    '/effects.php', '/api.php', '/showplayer.php', '/desc_item.php',
    '/desc_skill.php', '/desc_effect.php', '/campground.php', '/trophies.php',
    '/account_tattoos.php', '/craft.php', '/choice.php'
  ] as const,
  // A 301/302/303 after a mutation may be followed only to these result/readback
  // pages. adventure.php is intentionally excluded so one logical mutation cannot
  // silently spend a second turn via redirect.
  allowedMutationRedirectReadPaths: [
    '/fight.php', '/fambattle.php', '/choice.php', '/main.php', '/charpane.php'
  ] as const,
  maxTurnsPerBatch: 10,
  absoluteMaxTurns: 100,
  maxFightRounds: 30,
  maxChoiceDepth: 10,
  maxRedirects: 5,
  maxUpstreamRequests: 96,
  upstreamTimeoutMs: 15_000,
  totalOperationTimeoutMs: 120_000,
  maxMutationBodyBytes: 64 * 1024,
  recentOperationTtlMs: 10 * 60_000,
  maxRecentOperations: 2048,
  maxSeedBytes: 10 * 1024 * 1024,
  maxSeedRows: 50_000,
  maxSeedColumns: 20,
  maxSeedFieldLength: 4096,
  allowedKvCategories: [
    'food', 'booze', 'familiars', 'skills', 'trophies', 'tattoos',
    'coolitems', 'mritems', 'hobocodes', 'info',
    'disc-food', 'disc-cocktail', 'disc-meat', 'disc-misc', 'disc-smith',
  ] as const,
  debugEnabled: false,
  wikiOrigin: 'https://wiki.kingdomofloathing.com',
  wikiProxyEnabled: false,
  wikiProxyOrigin: '',
});

function finiteInt(name: string, value: number, min: number): void {
  if (!Number.isFinite(value) || value !== Math.floor(value) || value < min) {
    throw new Error(`POLICY_INVALID: ${name} must be an integer >= ${min}`);
  }
}

export function validatePolicy(policy: Partial<PolicyConfig> = {}): PolicyConfig {
  const merged = { ...DEFAULT_POLICY, ...policy } as PolicyConfig;
  finiteInt('maxTurnsPerBatch', merged.maxTurnsPerBatch, 1);
  finiteInt('absoluteMaxTurns', merged.absoluteMaxTurns, 1);
  if (merged.absoluteMaxTurns < merged.maxTurnsPerBatch) {
    throw new Error('POLICY_INVALID: absoluteMaxTurns must be >= maxTurnsPerBatch');
  }
  finiteInt('maxFightRounds', merged.maxFightRounds, 1);
  finiteInt('maxChoiceDepth', merged.maxChoiceDepth, 1);
  finiteInt('maxRedirects', merged.maxRedirects, 0);
  finiteInt('maxUpstreamRequests', merged.maxUpstreamRequests, 1);
  finiteInt('upstreamTimeoutMs', merged.upstreamTimeoutMs, 1000);
  finiteInt('totalOperationTimeoutMs', merged.totalOperationTimeoutMs, merged.upstreamTimeoutMs);
  finiteInt('maxMutationBodyBytes', merged.maxMutationBodyBytes, 1024);
  finiteInt('recentOperationTtlMs', merged.recentOperationTtlMs, 1_000);
  finiteInt('maxRecentOperations', merged.maxRecentOperations, 1);
  finiteInt('maxSeedBytes', merged.maxSeedBytes, 1);
  finiteInt('maxSeedRows', merged.maxSeedRows, 1);
  finiteInt('maxSeedColumns', merged.maxSeedColumns, 1);
  finiteInt('maxSeedFieldLength', merged.maxSeedFieldLength, 1);
  if (!merged.allowedKolHosts.length || !merged.allowedKolHosts.includes(merged.canonicalKolHost)) {
    throw new Error('POLICY_INVALID: canonicalKolHost must be in allowedKolHosts');
  }
  if (!merged.allowedAuthenticatedReadPaths.length || merged.allowedAuthenticatedReadPaths.some(p => !p.startsWith('/'))) {
    throw new Error('POLICY_INVALID: allowedAuthenticatedReadPaths must contain absolute paths');
  }
  if (!merged.allowedMutationRedirectReadPaths.length || merged.allowedMutationRedirectReadPaths.some(p => !p.startsWith('/'))) {
    throw new Error('POLICY_INVALID: allowedMutationRedirectReadPaths must contain absolute paths');
  }
  const wiki = new URL(merged.wikiOrigin);
  if (wiki.protocol !== 'https:') throw new Error('POLICY_INVALID: wikiOrigin must use HTTPS');
  if (merged.wikiProxyEnabled) {
    const proxy = new URL(merged.wikiProxyOrigin);
    if (proxy.protocol !== 'https:') throw new Error('POLICY_INVALID: wikiProxyOrigin must use HTTPS');
  }
  return Object.freeze(merged);
}

export function computeTurnBudget(requested: number, policy: PolicyConfig): { budget: number; clamped: boolean } {
  if (!Number.isFinite(requested) || requested !== Math.floor(requested)) {
    throw new Error('INVALID_TURNS: must be a finite integer');
  }
  if (requested < 1) throw new Error('INVALID_TURNS: must be >= 1');
  const budget = Math.min(requested, policy.maxTurnsPerBatch, policy.absoluteMaxTurns);
  return { budget, clamped: budget < requested };
}
