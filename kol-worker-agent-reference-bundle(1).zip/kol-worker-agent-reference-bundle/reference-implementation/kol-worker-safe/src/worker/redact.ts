const SENSITIVE_HEADERS = new Set(['cookie','set-cookie','authorization','x-api-key','proxy-authorization','x-kol-csrf']);
const SENSITIVE_PARAMS = new Set(['pwd','key','secret','token','password','kv_seed_key']);

export function redactForLog(input: string): string {
  if (!input || typeof input !== 'string') return '';
  return input
    .replace(/([?&](?:pwd|key|secret|token|password|kv_seed_key)=)[^&\s]*/gi, '$1[REDACTED]')
    .replace(/(^|\n)(authorization|cookie|set-cookie|x-kol-csrf):\s*[^\r\n]*/gi, '$1$2: [REDACTED]')
    .replace(/\b(?:Bearer\s+)[A-Za-z0-9._~+/=-]{8,}\b/gi, 'Bearer [REDACTED]');
}

export function redactHeaders(headers: Record<string,string> | Headers): Record<string,string> {
  const out: Record<string,string> = {};
  const entries = headers instanceof Headers ? Array.from(headers.entries()) : Object.entries(headers);
  for (const [key,value] of entries) out[key] = SENSITIVE_HEADERS.has(key.toLowerCase()) ? '[REDACTED]' : redactForLog(value);
  return out;
}

export function redactUrl(url: string): string {
  try {
    const u = new URL(url);
    for (const p of SENSITIVE_PARAMS) if (u.searchParams.has(p)) u.searchParams.set(p, '[REDACTED]');
    return u.toString();
  } catch { return '[INVALID_URL]'; }
}

export interface SafeLogEntry {
  operationId: string; route: string; actionType: string; status: string; durationMs: number;
  errorClass?: string; details?: Record<string,string|number|boolean>;
}
export function formatLogEntry(entry: SafeLogEntry): string {
  const parts = [`[${entry.operationId}]`, redactForLog(entry.route), entry.actionType, `status=${entry.status}`, `duration=${entry.durationMs}ms`];
  if (entry.errorClass) parts.push(`error=${redactForLog(entry.errorClass)}`);
  if (entry.details) for (const [k,v] of Object.entries(entry.details)) parts.push(`${k}=${redactForLog(String(v))}`);
  return parts.join(' ');
}
