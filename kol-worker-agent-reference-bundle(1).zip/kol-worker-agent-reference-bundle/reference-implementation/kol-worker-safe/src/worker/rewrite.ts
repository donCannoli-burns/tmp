import { PolicyConfig } from './policy';

export function toProxyUrl(raw: string, policy: PolicyConfig): string {
  let u: URL;
  try { u = new URL(raw); } catch { return raw; }
  if (!policy.allowedKolHosts.includes(u.hostname.toLowerCase())) return raw;
  return `/_/${u.hostname}${u.pathname}${u.search}${u.hash}`;
}

export function rewriteTextUrls(text: string, policy: PolicyConfig): string {
  let out = text;
  for (const host of policy.allowedKolHosts) {
    out = out.replaceAll(`https://${host}`, `/_/${host}`);
    out = out.replaceAll(`http://${host}`, `/_/${host}`);
  }
  return out;
}

function rewriteAttributeValue(value: string, base: string, policy: PolicyConfig): string {
  const v = value.trim();
  if (/^(javascript|data|file|vbscript):/i.test(v)) return value;
  try {
    const u = new URL(v, base);
    if (policy.allowedKolHosts.includes(u.hostname.toLowerCase())) return toProxyUrl(u.toString(), policy);
  } catch { /* leave original */ }
  return value;
}

export function cspAllowsSelfScript(csp: string | null): boolean {
  if (!csp) return true;
  const directives = new Map<string,string[]>();
  for (const raw of csp.split(';')) {
    const tokens = raw.trim().split(/\s+/).filter(Boolean);
    if (tokens.length) directives.set(tokens[0].toLowerCase(), tokens.slice(1));
  }
  const sources = directives.get('script-src') || directives.get('default-src');
  if (!sources) return true;
  return sources.includes("'self'") || sources.includes('*');
}

/** Rewrites navigation attributes and injects only a same-origin external helper. */
export function rewriteHtml(html: string, baseUrl: string, policy: PolicyConfig, allowInjection: boolean): string {
  let out = html.replace(/\b(href|src|action|formaction)=(["'])([^"']*)\2/gi, (all, attr: string, quote: string, value: string) => {
    const rewritten = rewriteAttributeValue(value, baseUrl, policy);
    return `${attr}=${quote}${rewritten}${quote}`;
  });
  out = rewriteTextUrls(out, policy);
  if (allowInjection && !/\/ui\/auto-adventure\.js/i.test(out)) {
    const tag = '<script src="/ui/auto-adventure.js" defer></script>';
    out = /<\/body>/i.test(out) ? out.replace(/<\/body>/i, `${tag}</body>`) : `${out}${tag}`;
  }
  return out;
}

export function copySafeResponseHeaders(upstream: Record<string,string>, personalized: boolean): Headers {
  const headers = new Headers();
  const hop = new Set(['connection','keep-alive','proxy-authenticate','proxy-authorization','te','trailer','transfer-encoding','upgrade','set-cookie','content-length','content-encoding']);
  for (const [key,value] of Object.entries(upstream)) {
    if (!hop.has(key.toLowerCase())) headers.set(key,value);
  }
  if (personalized) {
    headers.set('Cache-Control','no-store, no-cache, must-revalidate, private');
    headers.set('Pragma','no-cache');
  }
  headers.set('X-Content-Type-Options','nosniff');
  return headers;
}
