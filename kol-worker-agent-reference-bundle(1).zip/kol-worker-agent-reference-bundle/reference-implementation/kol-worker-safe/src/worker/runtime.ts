import { DEFAULT_POLICY, PolicyConfig, validatePolicy } from './policy';
import { validateKolUrl, decodeProxyPath } from './host-policy';
import { extractKoLCookieHeader, transformUpstreamSetCookie, newCsrfToken, csrfCookieHeader, readSetCookieHeaders } from './cookies';
import { validateMutationCsrf, noStoreHeaders } from './csrf';
import { runAdventureBatch, resolveHumanChoice } from './adventure';
import { safeKoLRequest } from './safe-request';
import { validateSeedRequest } from './kv-seed';
import { KVNamespaceLike, buildAccountSnapshot, readSnapshotCategory, SNAPSHOT_ACCOUNT_CATEGORIES, snapshotAccountPage, snapshotCategoryPage, snapshotIndex, escapeHtml } from './snapshot';
import { autoAdventurePage, autoAdventureScript, kvSeedScript, snapshotScript } from './ui';
import { searchWikiLocations } from './wiki';
import { cspAllowsSelfScript, copySafeResponseHeaders, rewriteHtml, rewriteTextUrls, toProxyUrl } from './rewrite';
import { redactForLog } from './redact';

export interface WorkerEnv {
  SNAPSHOT_KV?: KVNamespaceLike;
  KV_SEED_KEY?: string;
  DEBUG?: string;
  WIKI_PROXY_ENABLED?: string;
  WIKI_PROXY_ORIGIN?: string;
  MAX_TURNS_PER_BATCH?: string;
  ABSOLUTE_MAX_TURNS?: string;
}

const inflightMutations = new Set<string>();
const recentMutationOperations = new Map<string,number>();

function json(data:unknown,status=200,extra:Record<string,string>={}):Response {
  return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff',...extra}});
}
function workerPageHeaders(cacheControl='no-store, no-cache, must-revalidate, private'):Record<string,string> {
  return {
    'Cache-Control':cacheControl,
    'Pragma':'no-cache',
    'Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; font-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
    'Referrer-Policy':'no-referrer',
    'X-Frame-Options':'DENY',
    'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
  };
}
function html(body:string,status=200,extra:Record<string,string>={}):Response {
  return new Response(body,{status,headers:{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff',...workerPageHeaders(),...extra}});
}
function policyFromEnv(env:WorkerEnv):PolicyConfig {
  const overrides: Record<string, unknown> = {};
  if (env.DEBUG && env.DEBUG !== 'false') throw new Error('POLICY_INVALID: production DEBUG must remain false');
  if (env.WIKI_PROXY_ENABLED === 'true') {
    overrides.wikiProxyEnabled = true;
    overrides.wikiProxyOrigin = env.WIKI_PROXY_ORIGIN || '';
  }
  if (env.MAX_TURNS_PER_BATCH) overrides.maxTurnsPerBatch = Number(env.MAX_TURNS_PER_BATCH);
  if (env.ABSOLUTE_MAX_TURNS) overrides.absoluteMaxTurns = Number(env.ABSOLUTE_MAX_TURNS);
  return validatePolicy(overrides as Partial<PolicyConfig>);
}

async function requestBodyText(request:Request,maxBytes:number):Promise<string> {
  const declared=Number(request.headers.get('Content-Length')||'0');
  if(Number.isFinite(declared)&&declared>maxBytes)throw new Error('REQUEST_TOO_LARGE');
  const buf=await request.arrayBuffer();
  if(buf.byteLength>maxBytes)throw new Error('REQUEST_TOO_LARGE');
  return new TextDecoder('utf-8',{fatal:true}).decode(buf);
}
async function requestJson<T>(request:Request,maxBytes:number):Promise<T> {
  const text=await requestBodyText(request,maxBytes);
  try{return JSON.parse(text) as T}catch{throw new Error('INVALID_JSON')}
}

async function lockKey(cookie:string):Promise<string> {
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(cookie));
  return Array.from(new Uint8Array(digest).slice(0,12),b=>b.toString(16).padStart(2,'0')).join('');
}
function pruneRecentOperations(now:number,policy:PolicyConfig):void {
  for(const [key,seen] of recentMutationOperations){if(now-seen>policy.recentOperationTtlMs)recentMutationOperations.delete(key)}
  while(recentMutationOperations.size>policy.maxRecentOperations){const first=recentMutationOperations.keys().next().value as string|undefined;if(!first)break;recentMutationOperations.delete(first)}
}
async function withMutationLock<T>(cookie:string,operation:string,policy:PolicyConfig,fn:()=>Promise<T>):Promise<T> {
  const sessionKey=await lockKey(cookie), opKey=`${sessionKey}:${operation}`, now=Date.now();
  pruneRecentOperations(now,policy);
  if(recentMutationOperations.has(opKey))throw new Error('DUPLICATE_OPERATION_ID');
  if(inflightMutations.has(sessionKey))throw new Error('MUTATION_ALREADY_IN_FLIGHT');
  // Reserve the operation ID before any mutation starts. This intentionally favors
  // fail-closed duplicate suppression over automatic replay after an uncertain failure.
  recentMutationOperations.set(opKey,now);
  inflightMutations.add(sessionKey);
  try{return await fn()}finally{inflightMutations.delete(sessionKey)}
}

function koLCookie(request:Request):string { return extractKoLCookieHeader(request.headers.get('Cookie')||''); }
function requireSession(request:Request):string {
  const cookie=koLCookie(request);
  if(!cookie)throw new Error('SESSION_REQUIRED');
  return cookie;
}
function operationId(request:Request):string {
  const id=request.headers.get('X-KoL-Operation-Id')||'';
  if(!/^[A-Za-z0-9._:-]{8,128}$/.test(id))throw new Error('VALID_OPERATION_ID_REQUIRED');
  return id;
}

async function handleCsrf():Promise<Response> {
  const token=newCsrfToken();
  return json({token},200,{...noStoreHeaders(),'Set-Cookie':csrfCookieHeader(token)});
}

async function handleAdventure(request:Request,origin:string,policy:PolicyConfig):Promise<Response> {
  const csrf=validateMutationCsrf(request,origin); if(!csrf.ok)return json({error:csrf.reason},403,noStoreHeaders());
  let cookie:string, op:string; try{cookie=requireSession(request);op=operationId(request)}catch(e){return json({error:(e as Error).message},401,noStoreHeaders())}
  let input:{target:string;turns:number;macroId?:string;knownChoices?:Record<string,string>};
  try{input=await requestJson(request,policy.maxMutationBodyBytes)}catch(e){return json({error:(e as Error).message},400,noStoreHeaders())}
  if(typeof input.target!=='string'||typeof input.turns!=='number'||(input.macroId!==undefined&&typeof input.macroId!=='string')||input.knownChoices!==undefined&&(typeof input.knownChoices!=='object'||Array.isArray(input.knownChoices)))return json({error:'INVALID_INPUT'},400,noStoreHeaders());
  try{
    const result=await withMutationLock(cookie,op,policy,()=>runAdventureBatch(input,cookie,origin,policy));
    console.log(`[${op}] /api/auto-adventure/run mutation status=ok turnsIssued=${result.turnsIssued} completed=${result.completed} upstream=${result.upstreamRequests}`);
    return json(result,200,noStoreHeaders());
  }catch(e){const message=(e as Error).message;console.log(`[${op}] /api/auto-adventure/run mutation status=error class=${redactForLog(message)}`);return json({error:message},message==='MUTATION_ALREADY_IN_FLIGHT'||message==='DUPLICATE_OPERATION_ID'?409:400,noStoreHeaders())}
}

async function handleChoice(request:Request,origin:string,policy:PolicyConfig):Promise<Response> {
  const csrf=validateMutationCsrf(request,origin); if(!csrf.ok)return json({error:csrf.reason},403,noStoreHeaders());
  let cookie:string,op:string;try{cookie=requireSession(request);op=operationId(request)}catch(e){return json({error:(e as Error).message},401,noStoreHeaders())}
  let input:{whichchoice:string;option:string;expectedKey:string};try{input=await requestJson(request,policy.maxMutationBodyBytes)}catch(e){return json({error:(e as Error).message},400,noStoreHeaders())}
  if(!input||typeof input.whichchoice!=='string'||typeof input.option!=='string'||typeof input.expectedKey!=='string')return json({error:'INVALID_INPUT'},400,noStoreHeaders());
  try{const result=await withMutationLock(cookie,op,policy,()=>resolveHumanChoice(input,cookie,policy));console.log(`[${op}] /api/choice/resolve mutation status=${result.ok?'ok':'stopped'}`);return result.ok?json(result,200,noStoreHeaders()):json({error:result.error,outcomeUnknown:result.outcomeUnknown||false},409,noStoreHeaders())}
  catch(e){return json({error:(e as Error).message},409,noStoreHeaders())}
}

async function handleStatus(request:Request,policy:PolicyConfig):Promise<Response> {
  let cookie:string;try{cookie=requireSession(request)}catch(e){return json({error:(e as Error).message},401,noStoreHeaders())}
  const target=`https://${policy.canonicalKolHost}/api.php?what=status&for=kol-worker-safe`;
  const res=await safeKoLRequest(target,{cookie,policy,intent:'read'});
  if(!res.ok)return json({error:res.code},res.code.includes('SESSION')?401:502,noStoreHeaders());
  let data:Record<string,unknown>;try{data=JSON.parse(res.response.body) as Record<string,unknown>}catch{return json({error:'STATUS_PARSE_FAILED'},502,noStoreHeaders())}
  const spleenUse=data.spleenuse??data.spleen??null;
  const spleenLimit=data.spleenlimit??data.spleen_limit??null;
  return json({spleenUse,spleenLimit,turns:data.adventures??null,level:data.level??null},200,noStoreHeaders());
}

async function handleWikiSearch(request:Request,policy:PolicyConfig):Promise<Response> {
  const q=new URL(request.url).searchParams.get('q')||'';
  try{return json({results:await searchWikiLocations(q,policy)},200,{'Cache-Control':'public, max-age=60'})}
  catch{return json({error:'WIKI_LOOKUP_FAILED'},502)}
}

function kvSeedPage(policy:PolicyConfig):string {
  const cats=policy.allowedKvCategories.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KV seed</title></head><body><main><h1>Snapshot KV seed</h1><p>The admin secret stays in memory only and is sent in the Authorization header. It is never placed in the URL or persisted in browser storage.</p><label>Category <select id="cat">${cats}</select></label><br><label>Secret <input id="secret" type="password" autocomplete="off"></label><br><label>TSV file <input id="file" type="file"></label><br><button id="send">Validate & commit</button><pre id="out"></pre></main><script src="/ui/kv-seed.js" defer></script></body></html>`;
}

async function handleKvSeed(request:Request,env:WorkerEnv,category:string,policy:PolicyConfig):Promise<Response> {
  const url=new URL(request.url);
  if([...url.searchParams.keys()].some(k=>/key|secret|token|password/i.test(k)))return json({error:'ADMIN_SECRET_MUST_NOT_BE_IN_URL'},400,noStoreHeaders());
  const origin=request.headers.get('Origin');
  if(origin!==url.origin)return json({error:'ADMIN_ORIGIN_MISMATCH'},403,noStoreHeaders());
  const fetchSite=request.headers.get('Sec-Fetch-Site');
  if(fetchSite&&fetchSite!=='same-origin')return json({error:'ADMIN_FETCH_SITE_REJECTED'},403,noStoreHeaders());
  if(!env.SNAPSHOT_KV)return json({error:'SNAPSHOT_KV_NOT_BOUND'},503,noStoreHeaders());
  let body:string;try{body=await requestBodyText(request,policy.maxSeedBytes)}catch(e){return json({error:(e as Error).message},413,noStoreHeaders())}
  const checked=validateSeedRequest({category,body,authHeader:request.headers.get('Authorization')},policy,env.KV_SEED_KEY||'');
  if(!checked.ok)return json({error:checked.error},checked.error.includes('AUTH')?401:400,noStoreHeaders());
  const candidate=JSON.stringify({version:1,category:checked.category,rows:checked.rows,seededAt:new Date().toISOString()});
  await env.SNAPSHOT_KV.put(`data:${checked.category}`,candidate);
  return json({ok:true,category:checked.category,rows:checked.rows.length},200,noStoreHeaders());
}

async function proxyRead(request:Request,targetUrl:string,cookie:string,policy:PolicyConfig):Promise<Response> {
  const v=validateKolUrl(targetUrl,policy);if(!v.ok)return json({error:v.reason},403,noStoreHeaders());
  if(!policy.allowedProxyReadPaths.includes(v.url.pathname))return json({error:'PROXY_PATH_NOT_READ_ONLY_ALLOWLISTED'},403,noStoreHeaders());
  const headers=new Headers();
  for(const h of ['Accept','Accept-Language','User-Agent']){const val=request.headers.get(h);if(val)headers.set(h,val)}
  if(cookie)headers.set('Cookie',cookie);
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),policy.upstreamTimeoutMs);
  let upstream:Response;try{upstream=await fetch(v.url.href,{method:request.method==='HEAD'?'HEAD':'GET',headers,redirect:'manual',signal:controller.signal})}catch{clearTimeout(timer);return json({error:'UPSTREAM_NETWORK_ERROR'},502,noStoreHeaders())}clearTimeout(timer);
  const outHeaders=copySafeResponseHeaders(Object.fromEntries(upstream.headers.entries()),!!cookie);
  for(const raw of readSetCookieHeaders(upstream.headers)){const transformed=transformUpstreamSetCookie(raw);if(transformed)outHeaders.append('Set-Cookie',transformed)}
  if([301,302,303,307,308].includes(upstream.status)){
    const loc=upstream.headers.get('Location');if(!loc)return json({error:'REDIRECT_WITHOUT_LOCATION'},502,noStoreHeaders());
    let resolved:URL;try{resolved=new URL(loc,v.url.href)}catch{return json({error:'INVALID_REDIRECT'},502,noStoreHeaders())}
    const valid=validateKolUrl(resolved.toString(),policy);if(!valid.ok)return json({error:'REDIRECT_REJECTED'},502,noStoreHeaders());
    if(cookie&&valid.url.pathname==='/login.php')return json({error:'SESSION_EXPIRED'},401,noStoreHeaders());
    if(!policy.allowedProxyReadPaths.includes(valid.url.pathname))return json({error:'REDIRECT_TO_NON_READ_PATH'},403,noStoreHeaders());
    outHeaders.set('Location',toProxyUrl(valid.url.href,policy));
    return new Response(null,{status:upstream.status,headers:outHeaders});
  }
  if(request.method==='HEAD')return new Response(null,{status:upstream.status,headers:outHeaders});
  const type=upstream.headers.get('Content-Type')||'';const body=await upstream.text();
  if(type.includes('text/html')){
    const csp=upstream.headers.get('Content-Security-Policy');
    const transformed=rewriteHtml(body,v.url.href,policy,cspAllowsSelfScript(csp));
    return new Response(transformed,{status:upstream.status,headers:outHeaders});
  }
  if(type.includes('css')||type.includes('javascript')||type.includes('json'))return new Response(rewriteTextUrls(body,policy),{status:upstream.status,headers:outHeaders});
  return new Response(body,{status:upstream.status,headers:outHeaders});
}

async function proxyLogin(request:Request,origin:string,policy:PolicyConfig):Promise<Response> {
  const reqOrigin=request.headers.get('Origin');if(reqOrigin!==origin)return json({error:'LOGIN_ORIGIN_MISMATCH'},403,noStoreHeaders());
  const site=request.headers.get('Sec-Fetch-Site');if(site&&site!=='same-origin')return json({error:'LOGIN_FETCH_SITE_REJECTED'},403,noStoreHeaders());
  let body:string;try{body=await requestBodyText(request,policy.maxMutationBodyBytes)}catch(e){return json({error:(e as Error).message},413,noStoreHeaders())}
  const headers=new Headers({'Content-Type':request.headers.get('Content-Type')||'application/x-www-form-urlencoded'});const cookie=koLCookie(request);if(cookie)headers.set('Cookie',cookie);
  const target=`https://${policy.canonicalKolHost}/login.php`;const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),policy.upstreamTimeoutMs);
  let upstream:Response;try{upstream=await fetch(target,{method:'POST',headers,body,redirect:'manual',signal:controller.signal})}catch{clearTimeout(timer);return json({error:'LOGIN_OUTCOME_UNKNOWN'},502,noStoreHeaders())}clearTimeout(timer);
  const outHeaders=copySafeResponseHeaders(Object.fromEntries(upstream.headers.entries()),true);
  for(const raw of readSetCookieHeaders(upstream.headers)){const transformed=transformUpstreamSetCookie(raw);if(transformed)outHeaders.append('Set-Cookie',transformed)}
  if([301,302,303].includes(upstream.status)){
    const loc=upstream.headers.get('Location');if(!loc)return json({error:'LOGIN_REDIRECT_INVALID'},502,noStoreHeaders());
    let resolved:URL;try{resolved=new URL(loc,target)}catch{return json({error:'LOGIN_REDIRECT_INVALID'},502,noStoreHeaders())}
    const valid=validateKolUrl(resolved.toString(),policy);if(!valid.ok)return json({error:'LOGIN_REDIRECT_REJECTED'},502,noStoreHeaders());
    outHeaders.set('Location',toProxyUrl(valid.url.href,policy));return new Response(null,{status:303,headers:outHeaders});
  }
  const type=upstream.headers.get('Content-Type')||'';const text=await upstream.text();return new Response(type.includes('text/html')?rewriteHtml(text,target,policy,cspAllowsSelfScript(upstream.headers.get('Content-Security-Policy'))):text,{status:upstream.status,headers:outHeaders});
}

async function route(request:Request,env:WorkerEnv):Promise<Response> {
  let policy:PolicyConfig;try{policy=policyFromEnv(env)}catch(e){return json({error:'INVALID_SERVER_POLICY',detail:(e as Error).message},500,noStoreHeaders())}
  const url=new URL(request.url), origin=url.origin, path=url.pathname, method=request.method.toUpperCase();
  if(method==='OPTIONS')return new Response(null,{status:204,headers:{'Allow':'GET, HEAD, POST, OPTIONS'}});
  if(path==='/api/csrf'&&method==='GET')return handleCsrf();
  if(path==='/api/auto-adventure/run')return method==='POST'?handleAdventure(request,origin,policy):json({error:'METHOD_NOT_ALLOWED'},405);
  if(path==='/api/choice/resolve')return method==='POST'?handleChoice(request,origin,policy):json({error:'METHOD_NOT_ALLOWED'},405);
  if((path==='/spleen'||path==='/api/status')&&method==='GET')return handleStatus(request,policy);
  if(path==='/kol-locations/search'&&method==='GET')return handleWikiSearch(request,policy);
  if(path==='/auto-adventure'&&method==='GET')return html(autoAdventurePage(policy.maxTurnsPerBatch),200,noStoreHeaders());
  if(path==='/ui/auto-adventure.js'&&method==='GET')return new Response(autoAdventureScript(policy.maxTurnsPerBatch),{headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'}});
  if(path==='/ui/kv-seed.js'&&method==='GET')return new Response(kvSeedScript(),{headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'}});
  if(path==='/ui/snapshot.js'&&method==='GET')return new Response(snapshotScript(),{headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'}});
  if(path==='/kv-seed'&&method==='GET')return html(kvSeedPage(policy),200,noStoreHeaders());
  if(path.startsWith('/api/kv-seed/'))return method==='POST'?handleKvSeed(request,env,decodeURIComponent(path.slice('/api/kv-seed/'.length)),policy):json({error:'METHOD_NOT_ALLOWED'},405);
  if(path==='/snapshot'&&method==='GET')return html(snapshotIndex(),200,workerPageHeaders('no-store, no-cache, must-revalidate, private'));
  if(path.startsWith('/snapshot/data/')&&method==='GET'){
    const category=decodeURIComponent(path.slice('/snapshot/data/'.length));let cookie:string;try{cookie=requireSession(request)}catch(e){return json({error:(e as Error).message},401,noStoreHeaders())}
    const data=await buildAccountSnapshot(category,env.SNAPSHOT_KV,cookie,policy);return data.ok?json(data,200,noStoreHeaders()):json({error:data.error},data.error==='SESSION_REQUIRED'?401:404,noStoreHeaders());
  }
  if(path.startsWith('/snapshot/reference/')&&method==='GET'){
    const category=decodeURIComponent(path.slice('/snapshot/reference/'.length));const data=await readSnapshotCategory(env.SNAPSHOT_KV,category,policy);return data.ok?html(snapshotCategoryPage(category,data.rows),200,workerPageHeaders('public, max-age=300')):json({error:data.error},404);
  }
  if(path.startsWith('/snapshot/')&&method==='GET'){
    const category=decodeURIComponent(path.slice('/snapshot/'.length));return (SNAPSHOT_ACCOUNT_CATEGORIES as readonly string[]).includes(category)?html(snapshotAccountPage(category),200,noStoreHeaders()):json({error:'SNAPSHOT_CATEGORY_NOT_SUPPORTED'},404,noStoreHeaders());
  }
  const decoded=decodeProxyPath(path);const host=decoded?.host||policy.canonicalKolHost;const targetPath=decoded?.path||path;const target=`https://${host}${targetPath}${url.search}`;
  if(method==='POST'&&targetPath==='/login.php'&&host===policy.canonicalKolHost)return proxyLogin(request,origin,policy);
  if(method!=='GET'&&method!=='HEAD')return json({error:'GENERIC_PROXY_MUTATION_FORBIDDEN'},405,noStoreHeaders());
  return proxyRead(request,target,koLCookie(request),policy);
}

export default { async fetch(request:Request,env:WorkerEnv):Promise<Response>{ try{return await route(request,env)}catch(e){console.log(`worker_error class=${redactForLog((e as Error).message)}`);return json({error:'INTERNAL_ERROR'},500,noStoreHeaders())} } };
export { route, policyFromEnv, proxyRead };
