import { PolicyConfig } from './policy';
import { validateKolUrl, validateRedirectLocation, ValidatedKolUrl } from './host-policy';

export type RequestIntent = 'read' | 'mutation' | 'session';
export type FetchFunction = (url: string, init: RequestInit) => Promise<Response>;

export interface OperationBudget {
  readonly max: number;
  used: number;
}
export function createOperationBudget(max: number): OperationBudget { return { max, used: 0 }; }

export interface SafeKoLRequestOptions {
  method?: string;
  headers?: Record<string, string>;
  body?: string | URLSearchParams;
  cookie: string;
  policy: PolicyConfig;
  signal?: AbortSignal;
  intent?: RequestIntent;
  budget?: OperationBudget;
}

export interface SafeKoLResponse {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  finalUrl: ValidatedKolUrl;
  redirectCount: number;
  requestCount: number;
}
export type SafeKoLResult =
  | { ok: true; response: SafeKoLResponse }
  | { ok: false; error: string; code: string; outcomeUnknown?: boolean };

let _fetchImpl: FetchFunction = typeof fetch !== 'undefined' ? fetch.bind(globalThis) : (() => { throw new Error('No fetch'); });
export function setFetchImplementation(fn: FetchFunction): void { _fetchImpl = fn; }
export function resetFetchImplementation(): void { _fetchImpl = typeof fetch !== 'undefined' ? fetch.bind(globalThis) : (() => { throw new Error('No fetch'); }); }

function isRedirect(status: number): boolean { return [301, 302, 303, 307, 308].includes(status); }
function normalizeMethod(method: string): string { return method.toUpperCase(); }
function bodyBytes(body?: string | URLSearchParams): number {
  if (!body) return 0;
  return new TextEncoder().encode(typeof body === 'string' ? body : body.toString()).length;
}

function mergeAbortSignals(external: AbortSignal | undefined, timeoutMs: number): { signal: AbortSignal; cancel: () => void } {
  const controller = new AbortController();
  const onAbort = () => controller.abort();
  if (external) {
    if (external.aborted) controller.abort();
    else external.addEventListener('abort', onAbort, { once: true });
  }
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return {
    signal: controller.signal,
    cancel: () => {
      clearTimeout(timer);
      external?.removeEventListener('abort', onAbort);
    },
  };
}


function validateIntentPath(url: ValidatedKolUrl, intent: RequestIntent, policy: PolicyConfig): string | null {
  if (intent === 'read' || intent === 'session') {
    return policy.allowedAuthenticatedReadPaths.includes(url.pathname) ? null : 'AUTHENTICATED_READ_PATH_NOT_ALLOWED';
  }
  return null;
}

function consumeBudget(budget: OperationBudget | undefined, policy: PolicyConfig): boolean {
  if (!budget) return true;
  const ceiling = Math.min(budget.max, policy.maxUpstreamRequests);
  if (budget.used >= ceiling) return false;
  budget.used += 1;
  return true;
}

function buildSafeHeaders(url: ValidatedKolUrl, cookie: string, options: SafeKoLRequestOptions): Record<string, string> {
  const headers: Record<string, string> = {
    'Referer': 'https://www.kingdomofloathing.com/main.php',
    'Origin': 'https://www.kingdomofloathing.com',
  };
  if (cookie) headers['Cookie'] = cookie;
  if (options.headers) {
    for (const [key, value] of Object.entries(options.headers)) {
      const lower = key.toLowerCase();
      if (['cookie', 'origin', 'host', 'authorization', 'proxy-authorization'].includes(lower)) continue;
      if (/\r|\n/.test(value)) continue;
      headers[key] = value;
    }
  }
  void url; // validation proof object intentionally consumed by this helper boundary.
  return headers;
}

/**
 * Authenticated KoL request primitive. Destination validation happens before
 * credential construction. Redirects are manual and every hop is revalidated.
 * Mutating 307/308 redirects are not replayed automatically.
 */
export async function safeKoLRequest(targetUrl: string, options: SafeKoLRequestOptions, fetchFn?: FetchFunction): Promise<SafeKoLResult> {
  const fetchImpl = fetchFn || _fetchImpl;
  const validation = validateKolUrl(targetUrl, options.policy);
  if (!validation.ok) return { ok: false, error: validation.reason, code: 'URL_VALIDATION_FAILED' };

  let currentUrl = validation.url;
  let method = normalizeMethod(options.method || 'GET');
  let body: string | URLSearchParams | undefined = options.body;
  const intent = options.intent || (['GET', 'HEAD'].includes(method) ? 'read' : 'mutation');
  const initialPathError = validateIntentPath(currentUrl, intent, options.policy);
  if (initialPathError) return { ok: false, error: initialPathError, code: 'READ_PATH_REJECTED' };
  if (intent === 'mutation' && bodyBytes(body) > options.policy.maxMutationBodyBytes) {
    return { ok: false, error: 'MUTATION_BODY_TOO_LARGE', code: 'INPUT_REJECTED' };
  }
  let redirects = 0;
  let requests = 0;

  while (true) {
    if (!consumeBudget(options.budget, options.policy)) return { ok: false, error: 'UPSTREAM_REQUEST_LIMIT_EXCEEDED', code: 'REQUEST_LIMIT' };
    requests += 1;
    const headers = buildSafeHeaders(currentUrl, options.cookie, options);
    const timeout = mergeAbortSignals(options.signal, options.policy.upstreamTimeoutMs);
    const init: RequestInit = { method, headers, redirect: 'manual', signal: timeout.signal };
    if (body && method !== 'GET' && method !== 'HEAD') init.body = typeof body === 'string' ? body : body.toString();

    let response: Response;
    try {
      response = await fetchImpl(currentUrl.href, init);
    } catch {
      timeout.cancel();
      return intent === 'read' || intent === 'session'
        ? { ok: false, error: 'NETWORK_ERROR', code: 'NETWORK_ERROR' }
        : { ok: false, error: 'OUTCOME_UNKNOWN', code: 'OUTCOME_UNKNOWN', outcomeUnknown: true };
    }
    timeout.cancel();

    if (isRedirect(response.status)) {
      redirects += 1;
      if (redirects > options.policy.maxRedirects) return { ok: false, error: 'REDIRECT_LIMIT_EXCEEDED', code: 'REDIRECT_LIMIT' };
      const location = response.headers.get('Location');
      if (!location) return { ok: false, error: 'REDIRECT_WITHOUT_LOCATION', code: 'INVALID_REDIRECT' };
      const redirect = validateRedirectLocation(location, currentUrl.href, options.policy);
      if (!redirect.ok) return { ok: false, error: redirect.reason || 'INVALID_REDIRECT', code: 'REDIRECT_VALIDATION_FAILED' };
      const redirectPathError = validateIntentPath(redirect.validatedUrl!, intent, options.policy);
      if (redirectPathError) return { ok: false, error: redirectPathError, code: 'REDIRECT_PATH_REJECTED' };

      // Never replay a non-idempotent mutation through a 307/308 redirect.
      if (intent === 'mutation' && (response.status === 307 || response.status === 308)) {
        return { ok: false, error: 'OUTCOME_UNKNOWN_MUTATION_REDIRECT', code: 'OUTCOME_UNKNOWN', outcomeUnknown: true };
      }
      // A 301/302/303 after a mutation becomes a GET only when the destination is
      // an explicitly safe result/readback page. This prevents a redirect back to
      // adventure.php from silently spending another turn.
      if (intent === 'mutation' && [301, 302, 303].includes(response.status)) {
        if (!options.policy.allowedMutationRedirectReadPaths.includes(redirect.validatedUrl!.pathname)) {
          return { ok: false, error: 'MUTATION_REDIRECT_PATH_NOT_ALLOWED', code: 'MUTATION_REDIRECT_REJECTED' };
        }
        method = 'GET';
        body = undefined;
      } else if (intent === 'session' && [301, 302, 303].includes(response.status)) {
        method = 'GET';
        body = undefined;
      }
      currentUrl = redirect.validatedUrl!;
      continue;
    }

    if (response.status >= 400) {
      if (intent === 'mutation' && response.status >= 500) {
        return { ok: false, error: `UPSTREAM_HTTP_${response.status}_OUTCOME_UNKNOWN`, code: 'OUTCOME_UNKNOWN', outcomeUnknown: true };
      }
      return { ok: false, error: `UPSTREAM_HTTP_${response.status}`, code: response.status === 401 || response.status === 403 ? 'SESSION_OR_AUTH_ERROR' : 'UPSTREAM_HTTP_ERROR' };
    }

    const responseHeaders: Record<string, string> = {};
    response.headers.forEach((value, key) => { responseHeaders[key] = value; });
    let text: string;
    try { text = await response.text(); }
    catch {
      return intent === 'mutation'
        ? { ok: false, error: 'RESPONSE_READ_FAILED_OUTCOME_UNKNOWN', code: 'OUTCOME_UNKNOWN', outcomeUnknown: true }
        : { ok: false, error: 'RESPONSE_READ_FAILED', code: 'NETWORK_ERROR' };
    }
    return { ok: true, response: { status: response.status, statusText: response.statusText, headers: responseHeaders, body: text, finalUrl: currentUrl, redirectCount: redirects, requestCount: requests } };
  }
}

export type RequestType = 'read-only' | 'mutating' | 'public';
export function classifyRequestType(method: string, pathname: string): RequestType {
  const publicPaths = ['/kol-locations/search', '/snapshot', '/ui/'];
  if (publicPaths.some(p => pathname.startsWith(p))) return 'public';
  return ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method.toUpperCase()) ? 'mutating' : 'read-only';
}
export function assertMutatingMethod(method: string): void {
  if (method.toUpperCase() !== 'POST') throw new Error('MUTATION_REQUIRES_POST: GET mutations are forbidden');
}
