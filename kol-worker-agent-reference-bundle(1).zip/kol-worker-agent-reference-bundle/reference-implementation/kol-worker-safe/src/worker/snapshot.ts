import { PolicyConfig } from './policy';
import { createOperationBudget, FetchFunction, safeKoLRequest } from './safe-request';

export interface KVNamespaceLike {
  get(key:string):Promise<string|null>;
  put(key:string,value:string, options?:{expirationTtl?:number}):Promise<void>;
}

export const SNAPSHOT_ACCOUNT_CATEGORIES = [
  'familiars','trophies','tattoos','skills','food','booze',
  'disc-cocktail','disc-food','disc-meat','disc-smith','disc-misc','hobocodes',
] as const;
export type SnapshotAccountCategory = typeof SNAPSHOT_ACCOUNT_CATEGORIES[number];

export interface SnapshotOwnedItem { id:string; name:string; permed?:boolean }
export type AccountSnapshotResult =
  | {ok:true;category:SnapshotAccountCategory;ownedCount:number;totalCount:number;owned:SnapshotOwnedItem[]}
  | {ok:false;error:string};

export function escapeHtml(value:string):string { return value.replace(/[&<>"']/g,c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]!)); }

export function snapshotIndex():string {
  const links=SNAPSHOT_ACCOUNT_CATEGORIES.map(c=>`<li><a href="/snapshot/${encodeURIComponent(c)}">${escapeHtml(c)}</a></li>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KoL snapshot</title></head><body><main><h1>KoL account snapshot</h1><p>Authenticated pages are read transiently and are never written to KV. Responses are private/no-store.</p><ul>${links}</ul><p><a href="/main.php">KoL proxy</a></p></main></body></html>`;
}

/** Reference tables are deployer-provided KV data, not personalized account data. */
export async function readSnapshotCategory(kv:KVNamespaceLike|undefined, category:string, policy:PolicyConfig):Promise<{ok:true;rows:string[][]}|{ok:false;error:string}> {
  if (!policy.allowedKvCategories.includes(category)) return {ok:false,error:'CATEGORY_NOT_ALLOWED'};
  if (!kv) return {ok:false,error:'SNAPSHOT_KV_NOT_BOUND'};
  const raw=await kv.get(`data:${category}`);
  if (!raw) return {ok:false,error:'SNAPSHOT_DATA_NOT_SEEDED'};
  try {
    const parsed=JSON.parse(raw) as {version?:number;rows?:unknown};
    if (parsed.version!==1 || !Array.isArray(parsed.rows)) return {ok:false,error:'SNAPSHOT_DATA_CORRUPT'};
    const rows=parsed.rows;
    if (!rows.every(row=>Array.isArray(row)&&row.every(v=>typeof v==='string'))) return {ok:false,error:'SNAPSHOT_DATA_CORRUPT'};
    return {ok:true,rows:rows as string[][]};
  } catch { return {ok:false,error:'SNAPSHOT_DATA_CORRUPT'}; }
}

export function snapshotCategoryPage(category:string, rows:string[][]):string {
  const body=rows.slice(0,5000).map(row=>`<tr>${row.map(v=>`<td>${escapeHtml(v)}</td>`).join('')}</tr>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(category)} reference</title><style>body{font-family:system-ui}table{border-collapse:collapse;width:100%}td{border:1px solid #bbb;padding:4px;vertical-align:top}</style></head><body><p><a href="/snapshot">← snapshot</a></p><h1>${escapeHtml(category)} reference</h1><table><tbody>${body}</tbody></table></body></html>`;
}

export function snapshotAccountPage(category:string):string {
  const safe=escapeHtml(category);
  const endpoint=escapeHtml(`/snapshot/data/${encodeURIComponent(category)}`);
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Snapshot — ${safe}</title><style>body{font:15px system-ui;max-width:700px;margin:auto;padding:20px}li{padding:5px 0}.badge{margin-left:8px;font-size:12px}</style></head><body><main id="snapshot-account" data-endpoint="${endpoint}"><p><a href="/snapshot">← snapshot</a></p><h1>${safe}</h1><p id="stat">Loading…</p><ul id="list"></ul></main><script src="/ui/snapshot.js" defer></script></body></html>`;
}

function isAccountCategory(category:string):category is SnapshotAccountCategory {
  return (SNAPSHOT_ACCOUNT_CATEGORIES as readonly string[]).includes(category);
}

async function fetchAccountPages(paths:readonly string[],cookie:string,policy:PolicyConfig,fetchFn?:FetchFunction):Promise<{ok:true;text:string}|{ok:false;error:string}> {
  const budget=createOperationBudget(Math.min(policy.maxUpstreamRequests,Math.max(4,paths.length+1)));
  const chunks:string[]=[];
  for(const path of paths){
    const target=new URL(path,`https://${policy.canonicalKolHost}`).toString();
    const r=await safeKoLRequest(target,{cookie,policy,intent:'read',budget},fetchFn);
    if(!r.ok)return{ok:false,error:r.code};
    chunks.push(r.response.body);
  }
  return{ok:true,text:chunks.join('\n')};
}

function ownedFromSubstring(rows:string[][],html:string,category:SnapshotAccountCategory):SnapshotOwnedItem[]{
  const out:SnapshotOwnedItem[]=[];
  const lower=category==='food'||category==='booze';
  const haystack=lower?html.toLowerCase():html;
  for(const row of rows){
    const id=row[0]||'';let name=row[1]||'';let hit=false;
    if(category==='trophies'){ name=row[2]||row[1]||'';hit=!!row[1]&&haystack.includes('/'+row[1]); }
    else if(category==='tattoos'){ name=row[1]||'';hit=!!row[2]&&haystack.includes('/'+row[2]+'.gif'); }
    else if(category==='food'||category==='booze'){ hit=!!name&&haystack.includes('>'+name.toLowerCase()+'</a>'); }
    else if(category.startsWith('disc-')){ hit=!!name&&haystack.includes('>'+name+'<'); }
    else if(category==='hobocodes'){ hit=!!name&&haystack.includes(name); }
    if(hit)out.push({id,name});
  }
  return out;
}

const ACCOUNT_PAGE_PATHS:Record<Exclude<SnapshotAccountCategory,'familiars'|'skills'>,readonly string[]>={
  trophies:['/trophies.php'],
  tattoos:['/account_tattoos.php'],
  food:['/showconsumption.php'],
  booze:['/showconsumption.php'],
  'disc-cocktail':['/craft.php?mode=discoveries&what=cocktail'],
  'disc-food':['/craft.php?mode=discoveries&what=cook'],
  'disc-meat':['/craft.php?mode=discoveries&what=combine'],
  'disc-smith':['/craft.php?mode=discoveries&what=smith'],
  'disc-misc':['/craft.php?mode=discoveries&what=multi'],
  hobocodes:['/questlog.php?which=5'],
};

/**
 * Builds a personalized snapshot transiently. Raw authenticated KoL HTML never
 * enters KV and is discarded after the ownership comparison completes.
 */
export async function buildAccountSnapshot(category:string,kv:KVNamespaceLike|undefined,cookie:string,policy:PolicyConfig,fetchFn?:FetchFunction):Promise<AccountSnapshotResult>{
  if(!isAccountCategory(category))return{ok:false,error:'SNAPSHOT_CATEGORY_NOT_SUPPORTED'};
  if(!cookie)return{ok:false,error:'SESSION_REQUIRED'};
  const reference=await readSnapshotCategory(kv,category,policy);
  if(!reference.ok)return reference;
  let owned:SnapshotOwnedItem[]=[];
  if(category==='familiars'){
    const pages=await fetchAccountPages(['/familiar.php'],cookie,policy,fetchFn);if(!pages.ok)return pages;
    const ids=new Set<string>();const re=/\bname=["']?newfam["']?\s+value=["']?(\d+)["']?/gi;let m:RegExpExecArray|null;
    while((m=re.exec(pages.text))!==null)ids.add(m[1]);
    owned=reference.rows.filter(r=>ids.has(r[0]||'')).map(r=>({id:r[0]||'',name:r[1]||''}));
  }else if(category==='skills'){
    const pages=await fetchAccountPages(['/charsheet.php','/campground.php?action=bookshelf'],cookie,policy,fetchFn);if(!pages.ok)return pages;
    for(const row of reference.rows){const id=row[0]||'',name=row[1]||'';if(!name)continue;const hp=`>${name}</a> (<b>HP</b>)`,perm=`>${name}</a> (P)`,plain=`>${name}</a>`;if(pages.text.includes(hp))owned.push({id,name,permed:true});else if(pages.text.includes(perm)||pages.text.includes(plain))owned.push({id,name,permed:false});}
  }else{
    const pages=await fetchAccountPages(ACCOUNT_PAGE_PATHS[category],cookie,policy,fetchFn);if(!pages.ok)return pages;
    owned=ownedFromSubstring(reference.rows,pages.text,category);
  }
  owned.sort((a,b)=>Number(a.id)-Number(b.id));
  return{ok:true,category,ownedCount:owned.length,totalCount:reference.rows.length,owned};
}
