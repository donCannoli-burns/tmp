export function autoAdventurePage(maxTurns: number): string {
  const cap = Number.isFinite(maxTurns) ? Math.max(1, Math.floor(maxTurns)) : 10;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KoL Worker — Auto Adventure</title><style>
  :root{font-family:system-ui,sans-serif;color-scheme:light dark}body{margin:0;background:#101319;color:#f4f6fb}.wrap{max-width:760px;margin:0 auto;padding:20px}.card{background:#181d26;border:1px solid #313a49;border-radius:14px;padding:18px;box-shadow:0 8px 30px #0005}a{color:#9ac7ff}code{background:#0d1117;padding:2px 5px;border-radius:4px}.notice{opacity:.82}</style></head><body><main class="wrap"><h1>KoL Worker</h1><p class="notice">Mutations are explicit and bounded. Stop prevents the <em>next</em> request; it cannot undo a request already sent.</p><div id="kol-worker-app" data-max-turns="${cap}"></div><p><a href="/main.php">Back to KoL proxy</a></p></main><script src="/ui/auto-adventure.js" defer></script></body></html>`;
}

/** Static privileged UI script. Uses DOM APIs/textContent only; never eval/innerHTML. */
export function autoAdventureScript(maxTurns = 10): string {
  const cap = Number.isFinite(maxTurns) ? Math.max(1, Math.floor(maxTurns)) : 10;
  return String.raw`(()=>{
'use strict';
const STORE='kol-worker-auto-v1', CHOICES='kol-worker-choices-v1';
const state={running:false,stop:false,csrf:null,pending:null};
function el(tag,attrs={},text=''){const n=document.createElement(tag);for(const[k,v]of Object.entries(attrs)){if(k==='class')n.className=v;else if(k==='type')n.type=v;else n.setAttribute(k,String(v));}if(text)n.textContent=text;return n;}
function load(k,fallback){try{return JSON.parse(localStorage.getItem(k)||'null')||fallback}catch{return fallback}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}
function css(){if(document.getElementById('kol-worker-style'))return;const s=el('style',{id:'kol-worker-style'});s.textContent='#kol-worker-panel{font:14px system-ui,sans-serif;position:fixed;right:10px;bottom:10px;z-index:2147483646;width:min(390px,calc(100vw - 20px));max-height:85vh;overflow:auto;background:#151a22;color:#f4f6fb;border:1px solid #3b4658;border-radius:12px;padding:12px;box-shadow:0 10px 30px #0008}#kol-worker-panel input,#kol-worker-panel button{font:inherit;box-sizing:border-box}#kol-worker-panel input{width:100%;padding:7px;margin:3px 0 8px;background:#0f131a;color:inherit;border:1px solid #465269;border-radius:6px}#kol-worker-panel button{padding:7px 10px;margin:3px;border:0;border-radius:6px;background:#315d9b;color:white;cursor:pointer}#kol-worker-panel button[disabled]{opacity:.55;cursor:default}#kol-worker-log{white-space:pre-wrap;max-height:160px;overflow:auto;background:#0c1016;padding:8px;border-radius:6px}.kol-worker-row{display:flex;gap:6px;align-items:center}.kol-worker-row>*{flex:1}.kol-worker-choice{display:block!important;width:100%;text-align:left}';document.head.appendChild(s)}
async function getCsrf(){if(state.csrf)return state.csrf;const r=await fetch('/api/csrf',{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw new Error('CSRF setup failed');state.csrf=(await r.json()).token;return state.csrf}
async function mutate(path,payload,op){const token=await getCsrf();const r=await fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-KoL-Action':'mutate','X-KoL-CSRF':token,'X-KoL-Operation-Id':op},body:JSON.stringify(payload)});const data=await r.json().catch(()=>({error:'invalid response'}));if(!r.ok)throw new Error(data.error||('HTTP '+r.status));return data}
function inferredTarget(){if(location.pathname.includes('/_/')&&location.pathname.endsWith('/adventure.php'))return location.pathname+location.search;return ''}
function mount(root,injected){css();const saved=load(STORE,{}),choices=load(CHOICES,{});const panel=el('section',{id:'kol-worker-panel'});if(!injected){panel.style.position='relative';panel.style.right='auto';panel.style.bottom='auto';panel.style.width='auto';panel.style.maxHeight='none'}
const title=el('strong',{},'Auto-adventure');const target=el('input',{placeholder:'/_/www.kingdomofloathing.com/adventure.php?snarfblat=…',value:saved.target||inferredTarget()});target.value=saved.target||inferredTarget();const turns=el('input',{type:'number',min:'1',max:root.dataset.maxTurns||'10',value:saved.turns||'1'});turns.value=String(saved.turns||1);const macro=el('input',{placeholder:'Macro ID (optional)'});macro.value=saved.macro||'';const run=el('button',{},'Run');const stop=el('button',{},'Stop');const status=el('div',{},'Stopped');const log=el('pre',{id:'kol-worker-log'},'');const choicesBox=el('div');const spleen=el('span',{},'Spleen: ?');const refresh=el('button',{},'Refresh status');const locationSearch=el('input',{placeholder:'Search KoL location'});const search=el('button',{},'Find location');const locationResults=el('div');
function persist(){save(STORE,{target:target.value,turns:turns.value,macro:macro.value})}target.addEventListener('change',persist);turns.addEventListener('change',persist);macro.addEventListener('change',persist);
function line(t){log.textContent+=(log.textContent?'\n':'')+String(t);log.scrollTop=log.scrollHeight}
function lock(v){state.running=v;run.disabled=v;target.disabled=v;turns.disabled=v;macro.disabled=v;status.textContent=v?'Running':'Stopped'}
async function refreshStatus(){refresh.disabled=true;try{const r=await fetch('/spleen',{credentials:'same-origin',cache:'no-store'}),d=await r.json();if(!r.ok)throw new Error(d.error||('HTTP '+r.status));spleen.textContent='Spleen: '+String(d.spleenUse??'?')+' / '+String(d.spleenLimit??'?')+' · Turns: '+String(d.turns??'?')}catch(e){spleen.textContent='Status unavailable: '+String(e.message||e)}finally{refresh.disabled=false}}
async function findLocation(){const q=locationSearch.value.trim();locationResults.replaceChildren();if(!q)return;search.disabled=true;try{const r=await fetch('/kol-locations/search?q='+encodeURIComponent(q),{cache:'no-store'}),d=await r.json();if(!r.ok)throw new Error(d.error||('HTTP '+r.status));for(const item of d.results||[]){const b=el('button',{class:'kol-worker-choice'},String(item.name)+' (#'+String(item.snarfblat)+')');b.addEventListener('click',()=>{target.value='/_/www.kingdomofloathing.com/adventure.php?snarfblat='+encodeURIComponent(item.snarfblat);persist();locationResults.replaceChildren();line('Target: '+String(item.name))});locationResults.appendChild(b)}if(!(d.results||[]).length)locationResults.appendChild(el('span',{},'No adventure zones found.'))}catch(e){locationResults.appendChild(el('span',{},'Search error: '+String(e.message||e)))}finally{search.disabled=false}}
refresh.addEventListener('click',refreshStatus);search.addEventListener('click',findLocation);locationSearch.addEventListener('keydown',e=>{if(e.key==='Enter')findLocation()});
function showChoice(info){choicesBox.replaceChildren();state.pending=info;choicesBox.appendChild(el('p',{},'Unknown choice — select manually. The server will re-check the fingerprint before submitting.'));for(const opt of info.options||[]){const b=el('button',{class:'kol-worker-choice'},String(opt.option)+': '+String(opt.label||'(unlabelled)'));b.addEventListener('click',async()=>{b.disabled=true;try{const op=crypto.randomUUID();await mutate('/api/choice/resolve',{whichchoice:info.whichchoice,option:opt.option,expectedKey:info.key},op);if(confirm('Remember this answer only for this exact choice fingerprint?')){choices[info.key]=opt.option;save(CHOICES,choices)}line('Choice submitted; state refreshed. Start again to continue.');choicesBox.replaceChildren()}catch(e){line('Choice error: '+e.message)}finally{b.disabled=false}});choicesBox.appendChild(b)}}
stop.addEventListener('click',()=>{state.stop=true;line('Stop requested — no further turn will be issued after the in-flight request returns.')});
run.addEventListener('click',async()=>{if(state.running)return;state.stop=false;choicesBox.replaceChildren();persist();let count=Number(turns.value);if(!Number.isInteger(count)||count<1){line('Turns must be a positive integer.');return}const max=Number(root.dataset.maxTurns||10);count=Math.min(count,max);lock(true);try{for(let i=0;i<count;i++){if(state.stop)break;const op=crypto.randomUUID();const data=await mutate('/api/auto-adventure/run',{target:target.value,turns:1,macroId:macro.value||undefined,knownChoices:choices},op);for(const l of data.log||[])line(l);if(data.outcomeUnknown){line('OUTCOME UNKNOWN — refresh state before any retry.');break}if(data.unknownChoice){showChoice(data.unknownChoice);break}if(data.stopped&&data.reason){line('Stopped: '+data.reason);break}}}catch(e){line('Error: '+e.message)}finally{lock(false)}});
panel.append(title);const statRow=el('div',{class:'kol-worker-row'});statRow.append(spleen,refresh);panel.append(statRow,el('label',{},'Find location'),locationSearch);const searchRow=el('div',{class:'kol-worker-row'});searchRow.append(search);panel.append(searchRow,locationResults,el('label',{},'Target'),target,el('label',{},'Turns'),turns,el('label',{},'Macro'),macro);const row=el('div',{class:'kol-worker-row'});row.append(run,stop,status);panel.append(row,choicesBox,log);root.appendChild(panel);refreshStatus()}
function start(){const standalone=document.getElementById('kol-worker-app');if(standalone){mount(standalone,false);return}if(document.getElementById('kol-worker-panel'))return;const root=el('div');root.dataset.maxTurns='${cap}';document.body.appendChild(root);mount(root,true)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();`;
}


/** Static administrative seed UI. The bearer secret exists only in the input value and request header. */
export function kvSeedScript(): string {
  return String.raw`(()=>{
'use strict';
const byId=id=>document.getElementById(id);
const send=byId('send'),file=byId('file'),secret=byId('secret'),cat=byId('cat'),out=byId('out');
if(!send||!file||!secret||!cat||!out)return;
send.addEventListener('click',async()=>{
  const f=file.files&&file.files[0];if(!f){out.textContent='Select a TSV file first.';return}
  const token=String(secret.value||'');secret.value='';send.disabled=true;
  try{
    const r=await fetch('/api/kv-seed/'+encodeURIComponent(String(cat.value)),{method:'POST',credentials:'same-origin',headers:{Authorization:'Bearer '+token,'Content-Type':'text/plain;charset=utf-8'},body:await f.text()});
    out.textContent=await r.text();
  }catch(e){out.textContent='Request failed: '+String(e&&e.message||e)}finally{send.disabled=false}
});
})();`;
}

/** Static snapshot renderer. Server-provided strings are assigned through textContent only. */
export function snapshotScript(): string {
  return String.raw`(()=>{
'use strict';
const root=document.getElementById('snapshot-account'),stat=document.getElementById('stat'),list=document.getElementById('list');
if(!root||!stat||!list)return;const endpoint=String(root.dataset.endpoint||'');if(!endpoint.startsWith('/snapshot/data/')){stat.textContent='Invalid snapshot endpoint.';return}
fetch(endpoint,{credentials:'same-origin',cache:'no-store'}).then(async r=>({ok:r.ok,data:await r.json()})).then(({ok,data})=>{
  if(!ok||data.error){stat.textContent='Error: '+String(data.error||'request failed');return}
  stat.textContent=String(data.ownedCount)+' / '+String(data.totalCount);
  for(const item of data.owned||[]){const li=document.createElement('li'),name=document.createElement('span');name.textContent=String(item.name||'');li.appendChild(name);if(item.permed){const badge=document.createElement('span');badge.className='badge';badge.textContent='PERMED';li.appendChild(badge)}list.appendChild(li)}
}).catch(e=>{stat.textContent='Error: '+String(e&&e.message||e)});
})();`;
}
