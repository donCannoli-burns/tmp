import { PolicyConfig } from './policy';
import { FetchFunction } from './safe-request';

export interface LocationHit { name:string; snarfblat:string; url:string }

function wikiHeaders(): Record<string,string> { return { 'Accept':'application/json, text/html;q=0.9', 'User-Agent':'KoL-worker-safe/1.0' }; }
function stripTags(html:string):string{return html.replace(/<[^>]+>/g,' ')}
export function extractZoneNum(html:string):string|null{const m=stripTags(html).match(/\bZone\s+Num\s+(\d{1,9})\b/i);return m?m[1]:null}

function requestOrigin(policy:PolicyConfig):string{return policy.wikiProxyEnabled?policy.wikiProxyOrigin:policy.wikiOrigin}
function wikiPageUrl(title:string,origin:string):string{return new URL(`/index.php/${encodeURIComponent(title.replace(/ /g,'_'))}`,origin).toString()}

/** Public Wiki lookup only. No caller headers or KoL credentials are accepted. */
export async function searchWikiLocations(query:string, policy:PolicyConfig, fetchFn:FetchFunction = fetch.bind(globalThis)):Promise<LocationHit[]> {
  const q=query.trim();
  if (!q || q.length>120) return [];
  const origin=requestOrigin(policy);
  const api=new URL('/api.php',origin);
  api.search=new URLSearchParams({action:'opensearch',search:q,namespace:'0',limit:'12',format:'json'}).toString();
  const res=await fetchFn(api.toString(),{method:'GET',headers:wikiHeaders(),redirect:'manual'});
  if (!res.ok) throw new Error(`WIKI_HTTP_${res.status}`);
  const data=await res.json() as unknown;
  if(!Array.isArray(data)||!Array.isArray(data[1]))return[];
  const titles=(data[1] as unknown[]).filter((x):x is string=>typeof x==='string').slice(0,12);
  const results:LocationHit[]=[];
  for(const title of titles){
    if(results.length>=5)break;
    const page=wikiPageUrl(title,origin);
    let pageRes:Response;try{pageRes=await fetchFn(page,{method:'GET',headers:wikiHeaders(),redirect:'manual'})}catch{continue}
    if(!pageRes.ok)continue;
    const num=extractZoneNum(await pageRes.text());if(!num)continue;
    results.push({name:title,snarfblat:num,url:wikiPageUrl(title,policy.wikiOrigin)});
  }
  return results;
}
